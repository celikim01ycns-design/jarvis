# JARVIS: şimdilik özel kural gerekmiyor (minify kapalı).
-keepattributes *Annotation*
