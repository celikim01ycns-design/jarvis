package com.jarvis.app

import com.jarvis.app.data.local.DeviceDao
import com.jarvis.app.data.local.DeviceEntity
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.network.AgentConnection
import com.jarvis.app.network.Command
import com.jarvis.app.network.CommandProtocol
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

fun agent(id: String, name: String, online: Boolean = true) =
    DeviceInfo(id, name, DeviceType.AGENT, online, lastSeen = 0L)

/** Room olmadan bellekte çalışan DAO. */
class FakeDeviceDao : DeviceDao {
    private val rows = linkedMapOf<String, DeviceEntity>()
    override fun observeAll(): Flow<List<DeviceEntity>> = flowOf(rows.values.toList())
    override suspend fun getAll(): List<DeviceEntity> = rows.values.toList()
    override suspend fun getById(id: String): DeviceEntity? = rows[id]
    override suspend fun getByName(name: String): DeviceEntity? = rows.values.firstOrNull { it.name.equals(name, true) }
    override suspend fun upsert(entity: DeviceEntity) { rows[entity.id] = entity }
    override suspend fun delete(id: String) { rows.remove(id) }
    override suspend fun updateStatus(id: String, status: String, lastSeen: Long) {
        rows[id]?.let { rows[id] = it.copy(status = status, lastSeen = lastSeen) }
    }
    override suspend fun rename(id: String, name: String) {
        rows[id]?.let { rows[id] = it.copy(name = name) }
    }
    override suspend fun markAllOffline() {
        rows.keys.toList().forEach { k -> rows[k] = rows.getValue(k).copy(status = "OFFLINE") }
    }
}

/** Gönderilen mesajları kaydeden bağlantı; [onSend] ile yanıt simüle edilebilir. */
class FakeConnection(private val onSend: suspend (String) -> Unit = {}) : AgentConnection {
    val sent = mutableListOf<String>()
    var closed = false
    override suspend fun send(text: String): Boolean {
        sent += text
        onSend(text)
        return true
    }
    override suspend fun close(reason: String) { closed = true }
    fun lastCommand(): Command? = sent.mapNotNull { CommandProtocol.decode(it) as? Command }.lastOrNull()
}
