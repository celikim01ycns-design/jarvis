package com.jarvis.app

import com.jarvis.app.ai.MockGeminiService
import com.jarvis.app.device.AppRegistry
import com.jarvis.app.device.InstalledApp
import com.jarvis.app.domain.ActionValidator
import com.jarvis.app.domain.CommandParser
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.domain.LOCAL_TARGET
import com.jarvis.app.domain.ValidationResult
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ParsingAndValidationTest {
    private val phoneB = agent("b", "Telefon B")
    private val validator = ActionValidator()

    @Test fun `WhatsApp'i ac -> LOCAL + WhatsApp`() = runTest {
        val action = MockGeminiService().processCommand("WhatsApp'ı aç.", listOf(phoneB))
        assertEquals(JarvisAction.OpenApp(LOCAL_TARGET, "WhatsApp"), action)
    }

    @Test fun `Telefon B'de Spotify'i ac -> Telefon B + Spotify`() {
        val action = CommandParser.parse("Telefon B'de Spotify'ı aç", listOf(phoneB))
        assertEquals(JarvisAction.OpenApp("Telefon B", "Spotify"), action)
        val ok = validator.validate(action, listOf(phoneB)) as ValidationResult.Ok
        val send = ok.action as JarvisAction.SendToDevice
        assertEquals("b", send.deviceId)
        assertEquals("Spotify", (send.action as JarvisAction.OpenApp).app)
    }

    @Test fun `bu telefonda Chrome'u ac -> LOCAL`() {
        val action = CommandParser.parse("Bu telefonda Chrome'u aç", listOf(phoneB))
        assertEquals(JarvisAction.OpenApp(LOCAL_TARGET, "Chrome"), action)
    }

    @Test fun `bilinmeyen cihaz reddedilir`() {
        val action = CommandParser.parse("Telefon D'de Spotify'ı aç", listOf(phoneB))
        val result = validator.validate(action, listOf(phoneB))
        assertTrue(result is ValidationResult.Rejected)
        assertTrue((result as ValidationResult.Rejected).message.contains("bulunamadı"))
    }

    @Test fun `bilinmeyen uygulama bulunamaz`() {
        val registry = AppRegistry {
            listOf(InstalledApp("WhatsApp", "com.whatsapp"), InstalledApp("Spotify", "com.spotify.music"))
        }
        assertNull(registry.find("Fotoğraf Düzenleyici Pro"))
        assertEquals("com.whatsapp", registry.find("whatsapp")?.packageName)
        assertEquals("com.spotify.music", registry.find("Spotify'ı")?.packageName)
    }

    @Test fun `Turkce ad takma adla eslesir`() {
        val registry = AppRegistry { listOf(InstalledApp("Settings", "com.android.settings")) }
        assertNotNull(registry.find("Ayarlar"))
    }

    @Test fun `cevrimdisi cihaz reddedilir`() {
        val offline = agent("b", "Telefon B", online = false)
        val action = CommandParser.parse("Telefon B'de WhatsApp'ı aç", listOf(offline))
        val result = validator.validate(action, listOf(offline)) as ValidationResult.Rejected
        assertEquals("Telefon B şu anda çevrimdışı.", result.message)
    }

    @Test fun `gecersiz komut`() {
        val action = CommandParser.parse("merhaba nasılsın", listOf(phoneB))
        assertTrue(action is JarvisAction.Invalid)
        assertTrue(validator.validate(action, listOf(phoneB)) is ValidationResult.Rejected)
        assertTrue(CommandParser.parse("   ", emptyList()) is JarvisAction.Invalid)
    }
}
