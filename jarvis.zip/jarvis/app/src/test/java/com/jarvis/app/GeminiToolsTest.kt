package com.jarvis.app

import com.jarvis.app.ai.GeminiTools
import com.jarvis.app.domain.JarvisAction
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiToolsTest {
    private val json = Json { ignoreUnknownKeys = true }

    @Test fun `function_call adimi eyleme cevrilir`() {
        val body = """{"id":"x","status":"completed","steps":[{"type":"model_output"},
            {"type":"function_call","id":"c1","name":"open_app","arguments":{"target":"Telefon B","app":"Spotify"}}]}"""
        assertEquals(JarvisAction.OpenApp("Telefon B", "Spotify"), GeminiTools.parseResponse(body, json))
    }

    @Test fun `send_to_device ve hedefsiz open_app`() {
        val send = """{"steps":[{"type":"function_call","name":"send_to_device","arguments":{"device":"Telefon C","command":"open_app","app":"YouTube"}}]}"""
        assertEquals(JarvisAction.OpenApp("Telefon C", "YouTube"), GeminiTools.parseResponse(send, json))
        val local = """{"steps":[{"type":"function_call","name":"open_app","arguments":{"app":"Chrome"}}]}"""
        assertEquals(JarvisAction.OpenApp("LOCAL", "Chrome"), GeminiTools.parseResponse(local, json))
    }

    @Test fun `cagri yoksa veya desteklenmiyorsa guvenli sonuc`() {
        assertTrue(GeminiTools.parseResponse("""{"steps":[]}""", json) is JarvisAction.Invalid)
        val media = """{"steps":[{"type":"function_call","name":"play_media","arguments":{"target":"LOCAL"}}]}"""
        assertTrue(GeminiTools.parseResponse(media, json) is JarvisAction.Unsupported)
    }

    @Test fun `dokuz tool tanimli`() {
        assertEquals(9, GeminiTools.declarations.size)
    }
}
