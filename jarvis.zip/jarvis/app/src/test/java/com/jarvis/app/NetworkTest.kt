package com.jarvis.app

import com.jarvis.app.commands.AppOpener
import com.jarvis.app.commands.CommandRouter
import com.jarvis.app.commands.DeviceCommandSender
import com.jarvis.app.commands.LocalCommandExecutor
import com.jarvis.app.commands.RemoteCommandExecutor
import com.jarvis.app.domain.ActionValidator
import com.jarvis.app.domain.CommandParser
import com.jarvis.app.domain.CommandResult
import com.jarvis.app.network.AgentSessionHandler
import com.jarvis.app.network.Auth
import com.jarvis.app.network.AuthFailed
import com.jarvis.app.network.CommandProtocol
import com.jarvis.app.network.CommandResultMessage
import com.jarvis.app.network.DeviceManager
import com.jarvis.app.network.OpenAppPayload
import com.jarvis.app.network.PairAccepted
import com.jarvis.app.network.PairRejected
import com.jarvis.app.network.PairRequest
import com.jarvis.app.network.PairingCheck
import com.jarvis.app.network.PairingManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkTest {

    @Test fun `eslestirme kodunun suresi dolar`() {
        var now = 1_000L
        val pairing = PairingManager(clock = { now }, ttlMillis = 120_000)
        val code = pairing.createCode()
        assertTrue(code.code.matches(Regex("JARVIS-[A-Z2-9]{4}-[A-Z2-9]{4}")))
        now += 120_001
        assertEquals(PairingCheck.EXPIRED, pairing.consume(code.code))
        assertNull(pairing.activeCode())
    }

    @Test fun `eslestirme kodu tek kullanimlik ve esnek yazilir`() {
        val pairing = PairingManager()
        val code = pairing.createCode().code
        assertEquals(PairingCheck.OK, pairing.consume(code.lowercase().replace("jarvis-", "")))
        assertEquals(PairingCheck.INVALID, pairing.consume(code))
    }

    @Test fun `art arda yanlis denemeler kodu iptal eder`() {
        val pairing = PairingManager(maxFailures = 3)
        val code = pairing.createCode().code
        repeat(3) { assertEquals(PairingCheck.INVALID, pairing.consume("JARVIS-AAAA-AAAA")) }
        assertEquals(PairingCheck.INVALID, pairing.consume(code))
    }

    @Test fun `uzak komut zaman asimina ugrar`() = runTest {
        val manager = DeviceManager(FakeDeviceDao(), commandTimeoutMs = 10_000)
        manager.setServerIdentity("srv", "Ana Telefon")
        manager.addDevice("b", "Telefon B", "hash")
        manager.onAgentConnected("b", FakeConnection()) // yanıt vermeyen cihaz
        val result = manager.sendCommand("b", OpenAppPayload("Spotify"))
        assertFalse(result.success)
        assertTrue(result.timedOut)
        assertEquals("Telefon B yanıt vermiyor.", result.message)
    }

    @Test fun `uzak komut sonucu doner ve UUID tasir`() = runTest {
        val manager = DeviceManager(FakeDeviceDao())
        manager.setServerIdentity("srv", "Ana Telefon")
        manager.addDevice("b", "Telefon B", "hash")
        lateinit var conn: FakeConnection
        conn = FakeConnection {
            val cmd = conn.lastCommand()!!
            manager.onCommandResult("b", CommandResultMessage(cmd.commandId, true, "Spotify açıldı"))
        }
        manager.onAgentConnected("b", conn)
        val result = manager.sendCommand("b", OpenAppPayload("Spotify"))
        assertTrue(result.success)
        val cmd = conn.lastCommand()!!
        assertEquals("srv", cmd.sourceDevice)
        assertEquals("b", cmd.targetDevice)
        assertEquals(36, cmd.commandId.length)
    }

    @Test fun `baska cihazin sonucu kabul edilmez`() = runTest {
        val manager = DeviceManager(FakeDeviceDao(), commandTimeoutMs = 5_000)
        manager.setServerIdentity("srv", "Ana Telefon")
        manager.addDevice("b", "Telefon B", "h1")
        manager.addDevice("c", "Telefon C", "h2")
        lateinit var conn: FakeConnection
        conn = FakeConnection {
            manager.onCommandResult("c", CommandResultMessage(conn.lastCommand()!!.commandId, true, "sahte"))
        }
        manager.onAgentConnected("b", conn)
        assertTrue(manager.sendCommand("b", OpenAppPayload("X")).timedOut)
    }

    @Test fun `cevrimdisi cihaza komut gonderilmez`() = runTest {
        val manager = DeviceManager(FakeDeviceDao())
        manager.setServerIdentity("srv", "Ana Telefon")
        manager.addDevice("b", "Telefon B", "hash")
        val result = manager.sendCommand("b", OpenAppPayload("Spotify"))
        assertEquals("Telefon B şu anda çevrimdışı.", result.message)
    }

    @Test fun `cihaz adlari benzersizdir`() = runTest {
        val manager = DeviceManager(FakeDeviceDao())
        manager.setServerIdentity("srv", "Ana Telefon")
        manager.addDevice("b", "Telefon B", "h1")
        val second = manager.addDevice("c", "telefon b", "h2")
        assertEquals("telefon b (2)", second.name)
        assertFalse(manager.renameDevice("c", "Telefon B"))
        assertTrue(manager.renameDevice("c", "Tablet"))
    }

    @Test fun `eslesme ve sonraki token dogrulamasi`() = runTest {
        val pairing = PairingManager()
        val manager = DeviceManager(FakeDeviceDao())
        manager.setServerIdentity("srv", "Ana Telefon")
        val handler = AgentSessionHandler(pairing, manager)

        val bad = FakeConnection()
        val wrong = CommandProtocol.encode(PairRequest("JARVIS-XXXX-XXXX", "b", "Telefon B"))
        assertNull(handler.handshake(wrong, bad))
        assertTrue(CommandProtocol.decode(bad.sent.last()) is PairRejected)

        val code = pairing.createCode().code
        val conn = FakeConnection()
        val id = handler.handshake(CommandProtocol.encode(PairRequest(code, "b", "Telefon B")), conn)
        assertEquals("b", id)
        val accepted = CommandProtocol.decode(conn.sent.last()) as PairAccepted
        assertTrue(manager.isOnline("b"))

        val again = FakeConnection()
        assertEquals("b", handler.handshake(CommandProtocol.encode(Auth("b", accepted.sessionToken)), again))
        val forged = FakeConnection()
        assertNull(handler.handshake(CommandProtocol.encode(Auth("b", "sahte")), forged))
        assertTrue(CommandProtocol.decode(forged.sent.last()) is AuthFailed)

        manager.removeDevice("b")
        assertNull(handler.handshake(CommandProtocol.encode(Auth("b", accepted.sessionToken)), FakeConnection()))
    }

    @Test fun `protokol bozuk JSON'da null doner`() {
        assertNull(CommandProtocol.decode("{bozuk"))
        assertNotNull(CommandProtocol.decode(CommandProtocol.encode(com.jarvis.app.network.Ping(1))))
    }

    @Test fun `uctan uca yerel ve uzak yonlendirme`() = runTest {
        val phoneB = agent("b", "Telefon B")
        val devices = listOf(phoneB)
        val router = CommandRouter(
            validator = ActionValidator(),
            local = LocalCommandExecutor(AppOpener { CommandResult.ok("$it açıldı") }, { devices }, { "ok" }),
            remote = RemoteCommandExecutor(DeviceCommandSender { _, p -> CommandResult.ok("${(p as OpenAppPayload).app} açıldı") }),
            devicesProvider = { devices }
        )
        assertEquals("WhatsApp açıldı", router.route(CommandParser.parse("WhatsApp'ı aç", devices)).message)
        assertEquals(
            "Telefon B cihazında Spotify açıldı",
            router.route(CommandParser.parse("Telefon B'de Spotify'ı aç", devices)).message
        )
    }
}
