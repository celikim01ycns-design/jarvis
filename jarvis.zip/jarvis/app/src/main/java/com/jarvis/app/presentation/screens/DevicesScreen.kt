package com.jarvis.app.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors

@Composable
fun DevicesScreen(vm: JarvisViewModel, onBack: () -> Unit, onOpen: (String) -> Unit, onAdd: () -> Unit) {
    val devices by vm.devices.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = JarvisColors.Background,
        topBar = { JarvisTopBar("Cihazlar", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Yeni cihaz ekle") })
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(devices, key = { it.id }) { device ->
                val isServer = device.type == DeviceType.SERVER
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(JarvisColors.Surface)
                        .clickable(enabled = !isServer) { onOpen(device.id) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusDot(device.online)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(device.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            when {
                                isServer -> "Bu cihaz (Server)"
                                device.online -> "Çevrimiçi"
                                else -> "Çevrimdışı · son görülme ${formatLastSeen(device.lastSeen)}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = JarvisColors.Muted
                        )
                    }
                }
            }
            if (devices.count { it.type == DeviceType.AGENT } == 0) {
                item {
                    Text(
                        "Henüz eşleşmiş Agent yok. “Yeni cihaz ekle” ile kod oluşturun.",
                        color = JarvisColors.Muted,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }
    }
}
