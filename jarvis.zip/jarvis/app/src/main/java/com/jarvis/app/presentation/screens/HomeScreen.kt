package com.jarvis.app.presentation.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.presentation.ChatMessage
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors

@Composable
fun HomeScreen(
    vm: JarvisViewModel,
    onDevices: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val server by vm.serverState.collectAsStateWithLifecycle()
    val devices by vm.devices.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val listening by vm.listening.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { vm.startServer() }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startVoice()
    }
    val onMic: () -> Unit = {
        when {
            listening -> vm.stopVoice()
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED -> vm.startVoice()
            else -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(JarvisColors.Background)
            .statusBarsPadding()
            .imePadding()
    ) {
        // Başlık + durum
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("JARVIS", fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp, color = JarvisColors.Cyan)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(server.running)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when {
                            server.error != null -> server.error!!
                            server.running -> "Online · ${server.address ?: "ağ yok"}:${server.port}"
                            else -> "Sunucu kapalı"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (server.error != null) JarvisColors.Error else JarvisColors.Muted
                    )
                }
            }
            Switch(
                checked = server.running,
                onCheckedChange = { if (it) vm.startServer() else vm.stopServer() }
            )
            IconButton(onClick = onDevices) { Icon(Icons.Filled.Devices, "Cihazlar", tint = JarvisColors.Cyan) }
            IconButton(onClick = onHistory) { Icon(Icons.Filled.History, "Geçmiş", tint = JarvisColors.Cyan) }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Ayarlar", tint = JarvisColors.Cyan) }
        }

        // Bağlı cihazlar
        LazyRow(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(devices, key = { it.id }) { device ->
                AssistChip(
                    onClick = onDevices,
                    label = { Text(if (device.type == DeviceType.SERVER) "${device.name} · Bu cihaz" else device.name) },
                    leadingIcon = { StatusDot(device.online) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = JarvisColors.Surface,
                        labelColor = JarvisColors.Text
                    )
                )
            }
        }

        // Sohbet / son komutlar
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Komut ver", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        "“WhatsApp'ı aç”\n“Telefon B'de Spotify'ı aç”\n“Cihazlar neler?”",
                        color = JarvisColors.Muted,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { MessageBubble(it) }
            }
        }

        if (listening) {
            Text(
                text = if (partial.isBlank()) "Dinliyorum..." else partial,
                color = JarvisColors.Cyan,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)
            )
        }

        // Giriş çubuğu
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Komut yaz...") },
                singleLine = true,
                shape = RoundedCornerShape(24.dp)
            )
            FilledIconButton(
                onClick = {
                    vm.submit(input)
                    input = ""
                },
                enabled = input.isNotBlank() && !busy
            ) { Icon(Icons.Filled.Send, "Gönder") }
            MicButton(listening = listening, onClick = onMic)
        }
    }
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "mic")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )
    FilledIconButton(
        onClick = onClick,
        modifier = Modifier.size(52.dp).scale(if (listening) pulse else 1f)
    ) {
        Icon(if (listening) Icons.Filled.MicOff else Icons.Filled.Mic, if (listening) "Dinlemeyi durdur" else "Konuş")
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        val color = when {
            message.fromUser -> JarvisColors.SurfaceHigh
            message.success -> JarvisColors.Surface
            else -> JarvisColors.Error.copy(alpha = 0.18f)
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(color)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                (if (message.fromUser) "" else "JARVIS: ") + message.text,
                color = if (message.fromUser) JarvisColors.Cyan else JarvisColors.Text
            )
        }
    }
}
