package com.jarvis.app.presentation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.jarvis.app.data.AppMode
import com.jarvis.app.presentation.screens.AgentHomeScreen
import com.jarvis.app.presentation.screens.DeviceDetailScreen
import com.jarvis.app.presentation.screens.DevicesScreen
import com.jarvis.app.presentation.screens.HistoryScreen
import com.jarvis.app.presentation.screens.HomeScreen
import com.jarvis.app.presentation.screens.PairScreen
import com.jarvis.app.presentation.screens.SettingsScreen

object Routes {
    const val HOME = "home"
    const val DEVICES = "devices"
    const val DEVICE_DETAIL = "device_detail"
    const val PAIR = "pair"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val AGENT_HOME = "agent_home"
}

/** Server ve Agent için tek NavHost; başlangıç rotası moda göre seçilir. */
@Composable
fun JarvisNavHost(
    mode: AppMode,
    jarvisVm: JarvisViewModel,
    agentVm: AgentViewModel?,
    onSwitchMode: (AppMode) -> Unit
) {
    val nav = rememberNavController()
    val start = if (mode == AppMode.SERVER) Routes.HOME else Routes.AGENT_HOME

    NavHost(navController = nav, startDestination = start) {
        composable(Routes.HOME) {
            HomeScreen(
                vm = jarvisVm,
                onDevices = { nav.navigate(Routes.DEVICES) },
                onHistory = { nav.navigate(Routes.HISTORY) },
                onSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.DEVICES) {
            DevicesScreen(
                vm = jarvisVm,
                onBack = { nav.popBackStack() },
                onOpen = { id -> nav.navigate("${Routes.DEVICE_DETAIL}/$id") },
                onAdd = { nav.navigate(Routes.PAIR) }
            )
        }
        composable(
            route = "${Routes.DEVICE_DETAIL}/{deviceId}",
            arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
        ) { entry ->
            DeviceDetailScreen(
                vm = jarvisVm,
                deviceId = entry.arguments?.getString("deviceId").orEmpty(),
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.PAIR) { PairScreen(vm = jarvisVm, onBack = { nav.popBackStack() }) }
        composable(Routes.HISTORY) { HistoryScreen(vm = jarvisVm, onBack = { nav.popBackStack() }) }
        composable(Routes.SETTINGS) {
            SettingsScreen(vm = jarvisVm, mode = mode, onBack = { nav.popBackStack() }, onSwitchMode = onSwitchMode)
        }
        composable(Routes.AGENT_HOME) {
            if (agentVm != null) {
                AgentHomeScreen(vm = agentVm, onSettings = { nav.navigate(Routes.SETTINGS) })
            }
        }
    }
}
