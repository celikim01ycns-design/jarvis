package com.jarvis.app.ai

import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.JarvisAction

/** Kullanıcıya gösterilebilir mesaj taşıyan AI hatası (teknik ayrıntı içermez). */
class GeminiException(val userMessage: String, cause: Throwable? = null) : Exception(userMessage, cause)

/**
 * Doğal dil komutunu yapılandırılmış [JarvisAction]'a çevirir. Uygulayıcı yalnızca eylem üretir;
 * eylemi doğrulayıp çalıştırmak CommandRouter'ın işidir.
 * Hata durumunda [GeminiException] fırlatır.
 */
interface GeminiService {
    suspend fun processCommand(userCommand: String, devices: List<DeviceInfo>): JarvisAction
}
