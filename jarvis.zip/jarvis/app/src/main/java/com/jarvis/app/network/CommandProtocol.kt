package com.jarvis.app.network

import com.jarvis.app.domain.JarvisAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.util.UUID

/** Agent'a gönderilen eylemin tel üzerindeki biçimi: {"type":"open_app","app":"Spotify"} */
@Serializable
sealed class ActionPayload

@Serializable
@SerialName("open_app")
data class OpenAppPayload(val app: String) : ActionPayload()

@Serializable
@SerialName("device_status")
data object DeviceStatusPayload : ActionPayload()

/** Server <-> Agent arasındaki tüm JSON mesajları. "type" alanı mesaj türünü belirler. */
@Serializable
sealed class ProtocolMessage

/** Agent, tek kullanımlık eşleştirme koduyla ilk bağlantıyı ister. */
@Serializable
@SerialName("pair_request")
data class PairRequest(
    val pairingCode: String,
    val deviceId: String,
    val deviceName: String
) : ProtocolMessage()

@Serializable
@SerialName("pair_accepted")
data class PairAccepted(
    val serverId: String,
    val serverName: String,
    val sessionToken: String
) : ProtocolMessage()

@Serializable
@SerialName("pair_rejected")
data class PairRejected(val reason: String) : ProtocolMessage()

/** Eşleşmiş Agent sonraki bağlantılarda token ile kimlik doğrular. */
@Serializable
@SerialName("auth")
data class Auth(val deviceId: String, val sessionToken: String) : ProtocolMessage()

@Serializable
@SerialName("auth_ok")
data class AuthOk(val serverId: String) : ProtocolMessage()

@Serializable
@SerialName("auth_failed")
data class AuthFailed(val reason: String) : ProtocolMessage()

@Serializable
@SerialName("command")
data class Command(
    val commandId: String,
    val timestamp: Long,
    val sourceDevice: String,
    val targetDevice: String,
    val action: ActionPayload
) : ProtocolMessage()

@Serializable
@SerialName("command_result")
data class CommandResultMessage(
    val commandId: String,
    val success: Boolean,
    val message: String
) : ProtocolMessage()

@Serializable
@SerialName("ping")
data class Ping(val timestamp: Long) : ProtocolMessage()

@Serializable
@SerialName("pong")
data class Pong(val timestamp: Long) : ProtocolMessage()

@Serializable
@SerialName("disconnect")
data class Disconnect(val reason: String) : ProtocolMessage()

object CommandProtocol {
    val json: Json = Json {
        classDiscriminator = "type"
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun encode(message: ProtocolMessage): String =
        json.encodeToString(ProtocolMessage.serializer(), message)

    /** Geçersiz/bozuk JSON için istisna fırlatmaz, null döner. */
    fun decode(text: String): ProtocolMessage? = try {
        json.decodeFromString(ProtocolMessage.serializer(), text)
    } catch (e: SerializationException) {
        null
    } catch (e: IllegalArgumentException) {
        null
    }

    fun newCommand(
        sourceDevice: String,
        targetDevice: String,
        action: ActionPayload,
        now: Long = System.currentTimeMillis()
    ): Command = Command(
        commandId = UUID.randomUUID().toString(),
        timestamp = now,
        sourceDevice = sourceDevice,
        targetDevice = targetDevice,
        action = action
    )
}

/** Uzak cihazda çalıştırılabilecek eylemleri tel biçimine çevirir; desteklenmeyenler için null. */
fun JarvisAction.toPayload(): ActionPayload? = when (this) {
    is JarvisAction.OpenApp -> OpenAppPayload(app)
    is JarvisAction.DeviceStatus -> DeviceStatusPayload
    else -> null
}

/** Agent tarafında gelen eylemi yerel eyleme çevirir. */
fun ActionPayload.toLocalAction(): JarvisAction = when (this) {
    is OpenAppPayload -> JarvisAction.OpenApp(com.jarvis.app.domain.LOCAL_TARGET, app)
    DeviceStatusPayload -> JarvisAction.DeviceStatus(com.jarvis.app.domain.LOCAL_TARGET)
}
