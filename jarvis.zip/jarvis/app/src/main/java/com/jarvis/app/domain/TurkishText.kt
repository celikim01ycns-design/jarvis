package com.jarvis.app.domain

import java.util.Locale

/** Türkçe karakterleri ve büyük/küçük harf farkını eşleştirme için normalleştirir. */
object TurkishText {
    private val trLocale: Locale = Locale.forLanguageTag("tr-TR")
    private val nonWord = Regex("[^a-z0-9' ]")
    private val spaces = Regex("\\s+")

    fun normalize(input: String): String {
        val lower = input.lowercase(trLocale)
        val sb = StringBuilder(lower.length)
        for (c in lower) {
            sb.append(
                when (c) {
                    'ı' -> 'i'
                    'ö' -> 'o'
                    'ü' -> 'u'
                    'ş' -> 's'
                    'ç' -> 'c'
                    'ğ' -> 'g'
                    'â' -> 'a'
                    'î' -> 'i'
                    'û' -> 'u'
                    '’', '‘' -> '\''
                    else -> c
                }
            )
        }
        return sb.toString().replace(nonWord, " ").replace(spaces, " ").trim()
    }

    /** Boşluk ve kesme işaretleri atılmış karşılaştırma biçimi: "Google Maps" -> "googlemaps". */
    fun compact(input: String): String = normalize(input).replace("'", "").replace(" ", "")

    /** "whatsapp'i" -> "whatsapp" (Türkçe ek kesme işaretinden sonra gelir). */
    fun stem(token: String): String = token.substringBefore('\'').substringBefore('’')

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    /** 0.0 (tamamen farklı) ile 1.0 (aynı) arasında benzerlik. */
    fun similarity(a: String, b: String): Double {
        val longest = maxOf(a.length, b.length)
        if (longest == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / longest
    }
}
