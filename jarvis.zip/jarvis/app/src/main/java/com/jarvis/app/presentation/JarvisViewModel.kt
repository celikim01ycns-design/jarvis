package com.jarvis.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.AppContainer
import com.jarvis.app.data.local.CommandHistoryEntity
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.network.PairingCode
import com.jarvis.app.service.JarvisConnectionService
import com.jarvis.app.service.ServerState
import com.jarvis.app.voice.SpeechEvent
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String, val success: Boolean = true)

data class SettingsUi(
    val deviceName: String = "",
    val port: Int = 8765,
    val useMockAi: Boolean = true,
    val geminiModel: String = "",
    val hasApiKey: Boolean = false,
    val savedMessage: String? = null
)

/** Server tarafı ve Ayarlar için ortak ViewModel: komut hattı, ses, cihazlar, geçmiş, ayarlar. */
class JarvisViewModel(private val container: AppContainer) : ViewModel() {

    private val controller = container.serverController
    private val settings = container.settings

    val serverState: StateFlow<ServerState> = controller.state
    val devices: StateFlow<List<DeviceInfo>> = controller.devices

    val history: StateFlow<List<CommandHistoryEntity>> = container.database.commandHistoryDao()
        .observeRecent(100)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _listening = MutableStateFlow(false)
    val listening: StateFlow<Boolean> = _listening

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    private val _settingsUi = MutableStateFlow(SettingsUi())
    val settingsUi: StateFlow<SettingsUi> = _settingsUi

    private var voiceJob: Job? = null
    private var nextId = 0L

    init {
        loadSettings()
    }

    // --- Server yaşam döngüsü ---

    fun startServer() {
        viewModelScope.launch {
            controller.start()
            if (controller.state.value.running) {
                JarvisConnectionService.start(container.context, JarvisConnectionService.ROLE_SERVER)
            }
        }
    }

    fun stopServer() {
        viewModelScope.launch {
            controller.stop()
            JarvisConnectionService.stop(container.context)
        }
    }

    // --- Komutlar ---

    fun submit(text: String, fromVoice: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty() || _busy.value) return
        addMessage(fromUser = true, text = clean)
        _busy.value = true
        viewModelScope.launch {
            try {
                val outcome = controller.handleCommand(clean)
                addMessage(fromUser = false, text = outcome.reply, success = outcome.success)
                if (fromVoice) container.textToSpeech.speak(outcome.reply)
            } finally {
                _busy.value = false
            }
        }
    }

    fun startVoice() {
        if (_listening.value) return
        _listening.value = true
        _partial.value = ""
        voiceJob = viewModelScope.launch {
            try {
                container.speechRecognizer.listen().collect { event ->
                    when (event) {
                        SpeechEvent.Listening -> Unit
                        is SpeechEvent.Partial -> _partial.value = event.text
                        is SpeechEvent.Final -> submit(event.text, fromVoice = true)
                        is SpeechEvent.Error -> addMessage(fromUser = false, text = event.message, success = false)
                    }
                }
            } finally {
                _listening.value = false
                _partial.value = ""
            }
        }
    }

    fun stopVoice() {
        voiceJob?.cancel()
    }

    private fun addMessage(fromUser: Boolean, text: String, success: Boolean = true) {
        _messages.update { (it + ChatMessage(nextId++, fromUser, text, success)).takeLast(50) }
    }

    // --- Cihaz yönetimi ---

    fun createPairingCode(): PairingCode {
        controller.refreshAddress()
        return controller.newPairingCode()
    }

    fun disconnectDevice(id: String) {
        viewModelScope.launch { container.deviceManager.disconnect(id) }
    }

    fun removeDevice(id: String) {
        viewModelScope.launch { container.deviceManager.removeDevice(id) }
    }

    /** Başarılıysa true; ad boşsa veya başka cihazla çakışıyorsa false. */
    suspend fun renameDevice(id: String, name: String): Boolean = container.deviceManager.renameDevice(id, name)

    fun clearHistory() {
        viewModelScope.launch { container.database.commandHistoryDao().clear() }
    }

    // --- Ayarlar ---

    fun loadSettings() {
        viewModelScope.launch {
            _settingsUi.value = SettingsUi(
                deviceName = settings.getDeviceName(),
                port = settings.getServerPort(),
                useMockAi = settings.getUseMockAi(),
                geminiModel = settings.getGeminiModel(),
                hasApiKey = settings.hasGeminiApiKey()
            )
        }
    }

    fun saveSettings(deviceName: String, port: String, model: String, useMock: Boolean, apiKey: String) {
        viewModelScope.launch {
            val portNumber = port.toIntOrNull()
            if (portNumber == null || portNumber !in 1024..65535) {
                _settingsUi.update { it.copy(savedMessage = "Port 1024-65535 arasında olmalı.") }
                return@launch
            }
            if (deviceName.isNotBlank()) settings.setDeviceName(deviceName)
            settings.setServerPort(portNumber)
            if (model.isNotBlank()) settings.setGeminiModel(model)
            settings.setUseMockAi(useMock)
            if (apiKey.isNotBlank()) settings.setGeminiApiKey(apiKey)
            loadSettings()
            _settingsUi.update { it.copy(savedMessage = "Kaydedildi. Ad ve port, Server yeniden başlatılınca geçerli olur.") }
        }
    }

    fun clearApiKey() {
        settings.setGeminiApiKey("")
        loadSettings()
    }

    override fun onCleared() {
        voiceJob?.cancel()
        super.onCleared()
    }
}
