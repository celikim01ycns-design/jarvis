package com.jarvis.app.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.network.PairingCode
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors
import kotlinx.coroutines.delay

/** Server: tek kullanımlık eşleştirme kodu üretir; Agent bu kodu ve adresi girer. */
@Composable
fun PairScreen(vm: JarvisViewModel, onBack: () -> Unit) {
    val server by vm.serverState.collectAsStateWithLifecycle()
    val devices by vm.devices.collectAsStateWithLifecycle()
    var code by remember { mutableStateOf<PairingCode?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var agentsAtCreate by remember { mutableStateOf(0) }
    val agentCount = devices.count { it.type == DeviceType.AGENT }

    // Süre geri sayımı
    LaunchedEffect(code) {
        while (code != null) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    val current = code
    val remaining = if (current == null) 0L else ((current.expiresAt - now) / 1000).coerceAtLeast(0)
    val expired = current != null && remaining == 0L
    val paired = current != null && agentCount > agentsAtCreate

    Scaffold(containerColor = JarvisColors.Background, topBar = { JarvisTopBar("Yeni cihaz ekle", onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!server.running) {
                Text("Önce Server'ı başlatın (ana ekrandaki anahtar).", color = JarvisColors.Error)
            }
            Text(
                "1) Diğer telefonda JARVIS'i açıp “Agent” seçin.\n2) Aşağıdaki adresi ve kodu girin.\nKod tek kullanımlıktır ve kısa sürede geçersiz olur.",
                color = JarvisColors.Muted,
                style = MaterialTheme.typography.bodyMedium
            )
            Button(
                onClick = {
                    agentsAtCreate = agentCount
                    code = vm.createPairingCode()
                },
                enabled = server.running,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (current == null) "Eşleştirme kodu oluştur" else "Yeni kod oluştur") }

            if (current != null) {
                Spacer(Modifier.height(8.dp))
                Text("Server adresi", color = JarvisColors.Muted)
                Text(
                    "${server.address ?: "ağ bulunamadı"}:${server.port}",
                    fontSize = 22.sp, fontFamily = FontFamily.Monospace, color = JarvisColors.Text
                )
                Text("Eşleştirme kodu", color = JarvisColors.Muted)
                Text(
                    current.code,
                    fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                    color = if (expired || paired) JarvisColors.Offline else JarvisColors.Cyan,
                    textAlign = TextAlign.Center
                )
                Text(
                    when {
                        paired -> "Cihaz eşleşti. Kod kullanıldı."
                        expired -> "Kodun süresi doldu. Yeni kod oluşturun."
                        else -> "Kalan süre: ${remaining / 60}:${"%02d".format(remaining % 60)}"
                    },
                    color = if (paired) JarvisColors.Online else JarvisColors.Muted
                )
            }
        }
    }
}
