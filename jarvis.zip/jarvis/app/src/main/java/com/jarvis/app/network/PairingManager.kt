package com.jarvis.app.network

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

data class PairingCode(val code: String, val expiresAt: Long)

enum class PairingCheck { OK, INVALID, EXPIRED }

/**
 * Server tarafında tek kullanımlık, kısa ömürlü eşleştirme kodları üretir ve doğrular.
 * - Kod ömrü varsayılan 2 dakikadır.
 * - Başarılı kullanımdan sonra kod geçersiz olur (tek kullanım).
 * - Art arda [maxFailures] yanlış denemeden sonra aktif kod iptal edilir (kaba kuvvet koruması).
 * - Oturum token'ları rastgele üretilir; Server yalnızca SHA-256 özetini saklar.
 */
class PairingManager(
    private val clock: () -> Long = System::currentTimeMillis,
    private val ttlMillis: Long = DEFAULT_TTL_MS,
    private val maxFailures: Int = 5,
    private val random: SecureRandom = SecureRandom()
) {
    private var active: PairingCode? = null
    private var failures = 0

    @Synchronized
    fun createCode(): PairingCode {
        val body = CharArray(CODE_LENGTH) { ALPHABET[random.nextInt(ALPHABET.length)] }
        val code = "JARVIS-" + String(body, 0, 4) + "-" + String(body, 4, 4)
        val created = PairingCode(code, clock() + ttlMillis)
        active = created
        failures = 0
        return created
    }

    /** Süresi dolmamış aktif kod; yoksa null. */
    @Synchronized
    fun activeCode(): PairingCode? {
        val current = active ?: return null
        if (clock() > current.expiresAt) {
            active = null
            return null
        }
        return current
    }

    @Synchronized
    fun cancel() {
        active = null
        failures = 0
    }

    /** Kodu doğrular; başarılıysa kodu tüketir. */
    @Synchronized
    fun consume(input: String): PairingCheck {
        val current = active ?: return PairingCheck.INVALID
        if (clock() > current.expiresAt) {
            active = null
            return PairingCheck.EXPIRED
        }
        val matches = MessageDigest.isEqual(
            canonical(input).toByteArray(Charsets.UTF_8),
            canonical(current.code).toByteArray(Charsets.UTF_8)
        )
        if (!matches) {
            failures++
            if (failures >= maxFailures) active = null
            return PairingCheck.INVALID
        }
        active = null
        failures = 0
        return PairingCheck.OK
    }

    fun newSessionToken(): String {
        val bytes = ByteArray(32)
        random.nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }

    companion object {
        const val DEFAULT_TTL_MS = 120_000L
        private const val CODE_LENGTH = 8

        /** Karışabilecek karakterler (0/O, 1/I) yoktur. */
        private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

        /** "jarvis-7f4a-92kd" ve "7F4A92KD" aynı kodu ifade eder. */
        fun canonical(input: String): String =
            input.uppercase().filter { it.isLetterOrDigit() }.removePrefix("JARVIS")

        fun hashToken(token: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest(token.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
    }
}
