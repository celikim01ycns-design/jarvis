package com.jarvis.app.network

/**
 * Server'a gelen bir WebSocket oturumunun protokol mantığı (taşıyıcıdan bağımsız, test edilebilir).
 *
 * Her oturumun ilk mesajı kimlik doğrulama olmak zorundadır:
 *  - [PairRequest]: tek kullanımlık eşleştirme koduyla ilk eşleşme
 *  - [Auth]: daha önce eşleşmiş cihazın oturum token'ı
 * Doğrulanmayan oturumdan gelen başka hiçbir mesaj işlenmez.
 */
class AgentSessionHandler(
    private val pairing: PairingManager,
    private val devices: DeviceManager
) {

    /** Doğrulama başarılıysa cihaz id'sini döndürür; aksi halde reddi gönderip null döner. */
    suspend fun handshake(text: String, connection: AgentConnection): String? {
        return when (val message = CommandProtocol.decode(text)) {
            is PairRequest -> pair(message, connection)
            is Auth -> authenticate(message, connection)
            else -> {
                connection.send(CommandProtocol.encode(AuthFailed("Önce kimlik doğrulaması gerekli.")))
                null
            }
        }
    }

    private suspend fun pair(request: PairRequest, connection: AgentConnection): String? {
        if (request.deviceId.isBlank()) {
            connection.send(CommandProtocol.encode(PairRejected("Geçersiz cihaz bilgisi.")))
            return null
        }
        when (pairing.consume(request.pairingCode)) {
            PairingCheck.OK -> Unit
            PairingCheck.EXPIRED -> {
                connection.send(CommandProtocol.encode(PairRejected("Eşleştirme kodunun süresi dolmuş.")))
                return null
            }
            PairingCheck.INVALID -> {
                connection.send(CommandProtocol.encode(PairRejected("Eşleştirme kodu geçersiz.")))
                return null
            }
        }
        val token = pairing.newSessionToken()
        val device = devices.addDevice(request.deviceId, request.deviceName, PairingManager.hashToken(token))
        connection.send(
            CommandProtocol.encode(PairAccepted(devices.serverId(), devices.serverName(), token))
        )
        devices.onAgentConnected(device.id, connection)
        return device.id
    }

    private suspend fun authenticate(auth: Auth, connection: AgentConnection): String? {
        val ok = devices.verifyToken(auth.deviceId, PairingManager.hashToken(auth.sessionToken))
        if (!ok) {
            connection.send(CommandProtocol.encode(AuthFailed("Bu cihaz bu Server ile eşleşmiş değil.")))
            return null
        }
        connection.send(CommandProtocol.encode(AuthOk(devices.serverId())))
        devices.onAgentConnected(auth.deviceId, connection)
        return auth.deviceId
    }

    /** Doğrulanmış oturumdan gelen mesajlar. */
    suspend fun onMessage(deviceId: String, connection: AgentConnection, text: String) {
        when (val message = CommandProtocol.decode(text)) {
            is CommandResultMessage -> devices.onCommandResult(deviceId, message)
            is Ping -> connection.send(CommandProtocol.encode(Pong(message.timestamp)))
            is Pong -> Unit
            else -> Unit
        }
        devices.touch(deviceId)
    }

    suspend fun onClosed(deviceId: String, connection: AgentConnection) {
        devices.onAgentDisconnected(deviceId, connection)
    }
}
