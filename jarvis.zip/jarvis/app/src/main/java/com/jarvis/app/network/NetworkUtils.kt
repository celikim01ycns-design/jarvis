package com.jarvis.app.network

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {

    /**
     * Cihazın yerel ağdaki IPv4 adresi (Wi-Fi veya erişim noktası). Bulunamazsa null.
     * Agent bu adresi Server ekranında görüp eşleştirme sırasında girer.
     */
    fun localIpv4(): String? = try {
        val candidates = NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { nic ->
                nic.inetAddresses.toList()
                    .filterIsInstance<Inet4Address>()
                    .filter { it.isSiteLocalAddress }
                    .map { nic.name to (it.hostAddress ?: "") }
            }
            .filter { it.second.isNotEmpty() }
        (candidates.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("ap") }
            ?: candidates.firstOrNull())?.second
    } catch (e: Exception) {
        null
    }
}
