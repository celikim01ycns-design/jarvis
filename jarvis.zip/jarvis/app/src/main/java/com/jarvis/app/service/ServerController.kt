package com.jarvis.app.service

import com.jarvis.app.ai.GeminiException
import com.jarvis.app.ai.GeminiService
import com.jarvis.app.commands.AppOpener
import com.jarvis.app.commands.CommandRouter
import com.jarvis.app.commands.LocalCommandExecutor
import com.jarvis.app.commands.RemoteCommandExecutor
import com.jarvis.app.data.SettingsRepository
import com.jarvis.app.data.local.CommandHistoryDao
import com.jarvis.app.data.local.CommandHistoryEntity
import com.jarvis.app.domain.ActionValidator
import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.domain.LOCAL_TARGET
import com.jarvis.app.domain.typeName
import com.jarvis.app.network.AgentSessionHandler
import com.jarvis.app.network.DeviceManager
import com.jarvis.app.network.NetworkUtils
import com.jarvis.app.network.PairingManager
import com.jarvis.app.network.WebSocketManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class ServerState(
    val running: Boolean = false,
    val port: Int = 0,
    val address: String? = null,
    val error: String? = null
)

data class CommandOutcome(val reply: String, val success: Boolean)

/**
 * Server modunun orkestratörü: WebSocket sunucusunu açar/kapatır ve bir komut metnini
 * AI -> doğrulama -> yerel/uzak yürütme -> geçmiş kaydı hattından geçirir.
 */
class ServerController(
    private val settings: SettingsRepository,
    private val deviceManager: DeviceManager,
    private val pairing: PairingManager,
    private val historyDao: CommandHistoryDao,
    appOpener: AppOpener,
    private val serverStatus: () -> String,
    private val aiProvider: suspend () -> GeminiService,
    private val clock: () -> Long = System::currentTimeMillis
) {
    private val lifecycleMutex = Mutex()
    private val webSocketManager = WebSocketManager(AgentSessionHandler(pairing, deviceManager))

    private val router = CommandRouter(
        validator = ActionValidator(),
        local = LocalCommandExecutor(
            appOpener = appOpener,
            devicesProvider = { deviceManager.getAllDevices() },
            statusProvider = serverStatus
        ),
        remote = RemoteCommandExecutor(deviceManager),
        devicesProvider = { deviceManager.getAllDevices() }
    )

    private val _state = MutableStateFlow(ServerState())
    val state: StateFlow<ServerState> = _state

    val devices = deviceManager.devices

    suspend fun start() = lifecycleMutex.withLock {
        if (_state.value.running) return@withLock
        val port = settings.getServerPort()
        deviceManager.setServerIdentity(settings.getDeviceId(), settings.getDeviceName())
        deviceManager.load()
        try {
            webSocketManager.start(port)
            _state.value = ServerState(running = true, port = port, address = NetworkUtils.localIpv4())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.value = ServerState(error = "Sunucu başlatılamadı. Port $port kullanımda olabilir.")
        }
    }

    suspend fun stop() = lifecycleMutex.withLock {
        pairing.cancel()
        webSocketManager.stop()
        deviceManager.disconnectAll()
        _state.value = ServerState()
    }

    /** Yeni cihaz eklemek için tek kullanımlık kod üretir (Server çalışıyor olmalıdır). */
    fun newPairingCode() = pairing.createCode()

    fun refreshAddress() {
        val current = _state.value
        if (current.running) _state.value = current.copy(address = NetworkUtils.localIpv4())
    }

    suspend fun handleCommand(text: String): CommandOutcome {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return CommandOutcome("Komut boş.", false)

        val action: JarvisAction = try {
            aiProvider().processCommand(trimmed, deviceManager.getAllDevices())
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiException) {
            return record(trimmed, JarvisAction.Invalid(e.userMessage), CommandResult.fail(e.userMessage))
        } catch (e: Exception) {
            val message = "JARVIS AI servisine bağlanılamadı."
            return record(trimmed, JarvisAction.Invalid(message), CommandResult.fail(message))
        }

        val result = router.route(action)
        return record(trimmed, action, result)
    }

    private suspend fun record(text: String, action: JarvisAction, result: CommandResult): CommandOutcome {
        try {
            historyDao.insert(
                CommandHistoryEntity(
                    commandText = text,
                    targetDevice = targetOf(action),
                    actionType = action.typeName,
                    success = result.success,
                    result = result.message,
                    timestamp = clock()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Geçmiş kaydı başarısız olsa da kullanıcıya komut sonucu gösterilir.
        }
        return CommandOutcome(result.message, result.success)
    }

    private fun targetOf(action: JarvisAction): String = when (action) {
        is JarvisAction.OpenApp -> action.target
        is JarvisAction.DeviceStatus -> action.target
        is JarvisAction.SendToDevice -> action.deviceId
        else -> LOCAL_TARGET
    }
}
