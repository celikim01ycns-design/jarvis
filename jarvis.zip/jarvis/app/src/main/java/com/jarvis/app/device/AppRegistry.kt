package com.jarvis.app.device

import com.jarvis.app.domain.TurkishText

data class InstalledApp(
    val label: String,
    val packageName: String
)

/**
 * Cihazdaki başlatılabilir uygulamaları tutar ve ada göre eşleştirir.
 * Android'e bağımlı değildir: uygulama listesi `source` ile dışarıdan gelir (gerçekte PackageManager).
 * Package name'ler koda gömülü değildir; eşleşme etiket, package adı ve takma adlardan yapılır.
 */
class AppRegistry(private val source: () -> List<InstalledApp>) {

    @Volatile
    private var cache: List<InstalledApp>? = null

    fun refresh() {
        cache = source().distinctBy { it.packageName }
    }

    fun installed(): List<InstalledApp> {
        cache?.let { return it }
        refresh()
        return cache.orEmpty()
    }

    /** Bulunamazsa listeyi bir kez yenileyip tekrar dener (yeni kurulmuş uygulama olabilir). */
    fun find(query: String): InstalledApp? {
        val first = match(query, installed())
        if (first != null) return first
        refresh()
        return match(query, installed())
    }

    private fun match(query: String, apps: List<InstalledApp>): InstalledApp? {
        val normalizedQuery = stripNoise(TurkishText.normalize(query))
        if (normalizedQuery.isEmpty() || apps.isEmpty()) return null

        val candidates = linkedSetOf(normalizedQuery)
        aliases[TurkishText.compact(normalizedQuery)]?.let { candidates.addAll(it) }
        aliases[normalizedQuery]?.let { candidates.addAll(it) }

        val indexed = apps.map { Triple(it, TurkishText.normalize(it.label), TurkishText.compact(it.label)) }

        for (candidate in candidates) {
            val compact = candidate.replace(" ", "")

            // 1) Etiket tam eşleşmesi
            indexed.filter { it.second == candidate || it.third == compact }
                .minByOrNull { it.first.label.length }?.let { return it.first }

            // 2) Etiket sorguyla başlıyor / sorguyu içeriyor
            if (compact.length >= 3) {
                indexed.filter { it.third.startsWith(compact) }
                    .minByOrNull { it.first.label.length }?.let { return it.first }
                indexed.filter { it.third.contains(compact) }
                    .minByOrNull { it.first.label.length }?.let { return it.first }

                // 3) Package adında geçiyor ("whatsapp" -> com.whatsapp)
                apps.filter { it.packageName.lowercase().split('.').any { part -> part == compact } }
                    .minByOrNull { it.packageName.length }?.let { return it }
                apps.filter { it.packageName.lowercase().contains(compact) }
                    .minByOrNull { it.packageName.length }?.let { return it }
            }
        }

        // 4) Bulanık eşleşme (yazım hatası, ses tanıma hatası)
        val compactQuery = normalizedQuery.replace(" ", "")
        if (compactQuery.length >= 4) {
            val best = indexed
                .map { it to TurkishText.similarity(compactQuery, it.third) }
                .maxByOrNull { it.second }
            if (best != null && best.second >= 0.78) return best.first.first
        }
        return null
    }

    private fun stripNoise(normalized: String): String {
        val noise = setOf("uygulamasi", "uygulamasini", "uygulama", "app")
        // "spotify'ı" -> "spotify": kesme işaretinden sonraki Türkçe ek atılır.
        return normalized.split(' ').map { TurkishText.stem(it) }
            .filter { it.isNotEmpty() && it !in noise }.joinToString(" ").trim()
    }

    companion object {
        /** Türkçe sistem adları ile İngilizce etiketler arasında köprü. Anahtarlar normalize/compact biçimdedir. */
        private val aliases: Map<String, List<String>> = mapOf(
            "ayarlar" to listOf("settings", "ayarlar"),
            "ayar" to listOf("settings"),
            "kamera" to listOf("camera", "kamera"),
            "rehber" to listOf("contacts", "kisiler", "rehber"),
            "kisiler" to listOf("contacts", "kisiler"),
            "mesajlar" to listOf("messages", "mesajlar"),
            "saat" to listOf("clock", "saat"),
            "hesapmakinesi" to listOf("calculator", "hesap makinesi"),
            "harita" to listOf("maps", "harita"),
            "haritalar" to listOf("maps", "haritalar"),
            "takvim" to listOf("calendar", "takvim"),
            "galeri" to listOf("gallery", "photos", "fotograflar", "galeri"),
            "telefon" to listOf("phone", "telefon"),
            "tarayici" to listOf("chrome", "browser", "internet"),
            "muzik" to listOf("music", "spotify", "muzik")
        )
    }
}
