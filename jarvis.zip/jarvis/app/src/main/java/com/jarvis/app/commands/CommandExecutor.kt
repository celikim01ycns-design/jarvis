package com.jarvis.app.commands

import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.network.ActionPayload

interface CommandExecutor {
    suspend fun execute(action: JarvisAction): CommandResult
}

/** Bu cihazda bir uygulamayı açar (gerçek uygulaması AppLauncher). */
fun interface AppOpener {
    suspend fun open(appName: String): CommandResult
}

/** Çevrimiçi bir Agent'a komut yollayıp sonucunu bekler (gerçek uygulaması DeviceManager). */
fun interface DeviceCommandSender {
    suspend fun send(deviceId: String, payload: ActionPayload): CommandResult
}
