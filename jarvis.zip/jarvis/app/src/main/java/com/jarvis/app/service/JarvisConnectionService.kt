package com.jarvis.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.app.JarvisApp
import com.jarvis.app.MainActivity
import com.jarvis.app.R

/**
 * Server çalışırken veya Agent bağlıyken kalıcı bildirim gösteren ön plan servisi.
 * Bildirim, bağlantının etkin olduğunu açıkça gösterir ve "Bağlantıyı kes" düğmesi içerir.
 * Gerçek iş (sunucu/istemci) uygulama kapsayıcısındadır; servis yalnızca süreci canlı tutar.
 */
class JarvisConnectionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            (application as JarvisApp).container.stopAll()
            stopForegroundCompat()
            stopSelf()
            return START_NOT_STICKY
        }
        val role = intent?.getStringExtra(EXTRA_ROLE) ?: ROLE_SERVER
        ensureChannel()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(role), type)
        return START_NOT_STICKY
    }

    /** Android 15+: dataSync ön plan servislerinin süresi dolunca sistem çağırır; servis kendini sonlandırmalıdır. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        (application as JarvisApp).container.stopAll()
        stopForegroundCompat()
        stopSelf()
    }

    private fun stopForegroundCompat() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    private fun buildNotification(role: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, JarvisConnectionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (role == ROLE_AGENT) "Bu cihaz bir JARVIS Server'a bağlı. Komutları Server verir."
        else "Bu cihaz JARVIS Server olarak çalışıyor."
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Bağlantıyı kes", stop)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        const val ACTION_STOP = "com.jarvis.app.action.STOP"
        const val EXTRA_ROLE = "role"
        const val ROLE_SERVER = "server"
        const val ROLE_AGENT = "agent"
        private const val CHANNEL_ID = "jarvis_connection"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context, role: String) {
            ContextCompat.startForegroundService(
                context, Intent(context, JarvisConnectionService::class.java).putExtra(EXTRA_ROLE, role)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, JarvisConnectionService::class.java))
        }
    }
}
