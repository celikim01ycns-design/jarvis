package com.jarvis.app.domain

/** Komutu veren ana cihazı (Server) temsil eden hedef adı. */
const val LOCAL_TARGET = "LOCAL"

enum class DeviceType { SERVER, AGENT }

data class DeviceInfo(
    val id: String,
    val name: String,
    val type: DeviceType,
    val online: Boolean,
    val lastSeen: Long
)

data class CommandResult(
    val success: Boolean,
    val message: String,
    val timedOut: Boolean = false
) {
    companion object {
        fun ok(message: String) = CommandResult(true, message)
        fun fail(message: String) = CommandResult(false, message)
        fun timeout(message: String) = CommandResult(false, message, timedOut = true)
    }
}

/**
 * Yapay zekânın (veya yerel ayrıştırıcının) ürettiği yapılandırılmış eylem.
 * Model hiçbir zaman doğrudan Android API'si çalıştırmaz; yalnızca bu nesneyi üretir,
 * doğrulama ve çalıştırma uygulama koduna aittir.
 */
sealed class JarvisAction {
    data class OpenApp(val target: String, val app: String) : JarvisAction()
    data class SendToDevice(val deviceId: String, val action: JarvisAction) : JarvisAction()
    data class GetDevices(val requestId: String) : JarvisAction()
    data class DeviceStatus(val target: String) : JarvisAction()
    data class Invalid(val reason: String) : JarvisAction()
    data class Unsupported(val name: String) : JarvisAction()
}

val JarvisAction.typeName: String
    get() = when (this) {
        is JarvisAction.OpenApp -> "open_app"
        is JarvisAction.SendToDevice -> "send_to_device"
        is JarvisAction.GetDevices -> "get_devices"
        is JarvisAction.DeviceStatus -> "device_status"
        is JarvisAction.Invalid -> "invalid"
        is JarvisAction.Unsupported -> "unsupported"
    }
