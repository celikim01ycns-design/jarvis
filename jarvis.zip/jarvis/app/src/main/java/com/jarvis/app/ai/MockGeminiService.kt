package com.jarvis.app.ai

import com.jarvis.app.domain.CommandParser
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.JarvisAction

/** API anahtarı ve ağ olmadan çalışan, kural tabanlı sahte AI. Gerçek Gemini ile aynı eylem biçimini üretir. */
class MockGeminiService : GeminiService {
    override suspend fun processCommand(userCommand: String, devices: List<DeviceInfo>): JarvisAction =
        CommandParser.parse(userCommand, devices)
}
