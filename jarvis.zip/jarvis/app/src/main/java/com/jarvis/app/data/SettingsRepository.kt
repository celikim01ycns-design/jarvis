package com.jarvis.app.data

import android.os.Build
import com.jarvis.app.BuildConfig
import com.jarvis.app.data.local.SettingsDao
import com.jarvis.app.data.local.SettingsEntity
import com.jarvis.app.security.SecureStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

enum class AppMode { SERVER, AGENT }

/**
 * Ayarlar iki yerde tutulur: hassas olmayanlar Room'da, gizli olanlar (API anahtarı, oturum token'ı)
 * Keystore ile şifreli SecureStore'da.
 */
class SettingsRepository(
    private val dao: SettingsDao,
    private val secure: SecureStore
) {

    val mode: Flow<AppMode?> = dao.observe(KEY_MODE).map { value ->
        value?.let { runCatching { AppMode.valueOf(it) }.getOrNull() }
    }

    suspend fun getMode(): AppMode? =
        dao.get(KEY_MODE)?.let { runCatching { AppMode.valueOf(it) }.getOrNull() }

    suspend fun setMode(mode: AppMode) = put(KEY_MODE, mode.name)

    suspend fun getDeviceId(): String {
        dao.get(KEY_DEVICE_ID)?.let { return it }
        val id = UUID.randomUUID().toString()
        put(KEY_DEVICE_ID, id)
        return id
    }

    suspend fun getDeviceName(): String = dao.get(KEY_DEVICE_NAME) ?: defaultDeviceName()

    suspend fun setDeviceName(name: String) = put(KEY_DEVICE_NAME, name.trim())

    suspend fun getServerPort(): Int = dao.get(KEY_SERVER_PORT)?.toIntOrNull() ?: DEFAULT_PORT

    suspend fun setServerPort(port: Int) = put(KEY_SERVER_PORT, port.toString())

    suspend fun getGeminiModel(): String = dao.get(KEY_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL

    suspend fun setGeminiModel(model: String) = put(KEY_GEMINI_MODEL, model.trim())

    suspend fun getUseMockAi(): Boolean = dao.get(KEY_USE_MOCK)?.toBooleanStrictOrNull() ?: true

    suspend fun setUseMockAi(value: Boolean) = put(KEY_USE_MOCK, value.toString())

    /** Kullanıcının Ayarlar'dan girdiği anahtar öncelikli; yoksa local.properties'ten gelen geliştirme anahtarı. */
    fun getGeminiApiKey(): String =
        secure.getString(SECURE_GEMINI_KEY)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_API_KEY

    fun setGeminiApiKey(key: String) = secure.putString(SECURE_GEMINI_KEY, key.trim().ifEmpty { null })

    fun hasGeminiApiKey(): Boolean = getGeminiApiKey().isNotBlank()

    // --- Agent tarafı: eşleştiği Server'ın bilgileri ---

    suspend fun getPairedServer(): PairedServer? {
        val id = dao.get(KEY_PAIRED_SERVER_ID) ?: return null
        val name = dao.get(KEY_PAIRED_SERVER_NAME) ?: return null
        val host = dao.get(KEY_PAIRED_SERVER_HOST) ?: return null
        val port = dao.get(KEY_PAIRED_SERVER_PORT)?.toIntOrNull() ?: return null
        val token = secure.getString(SECURE_AGENT_TOKEN) ?: return null
        return PairedServer(id, name, host, port, token)
    }

    suspend fun savePairedServer(server: PairedServer) {
        put(KEY_PAIRED_SERVER_ID, server.serverId)
        put(KEY_PAIRED_SERVER_NAME, server.serverName)
        put(KEY_PAIRED_SERVER_HOST, server.host)
        put(KEY_PAIRED_SERVER_PORT, server.port.toString())
        secure.putString(SECURE_AGENT_TOKEN, server.sessionToken)
    }

    suspend fun clearPairedServer() {
        dao.delete(KEY_PAIRED_SERVER_ID)
        dao.delete(KEY_PAIRED_SERVER_NAME)
        dao.delete(KEY_PAIRED_SERVER_HOST)
        dao.delete(KEY_PAIRED_SERVER_PORT)
        secure.remove(SECURE_AGENT_TOKEN)
    }

    private suspend fun put(key: String, value: String) = dao.put(SettingsEntity(key, value))

    private fun defaultDeviceName(): String {
        val model = Build.MODEL?.trim().orEmpty()
        return if (model.isEmpty()) "Android Telefon" else model
    }

    companion object {
        const val DEFAULT_PORT = 8765
        const val DEFAULT_GEMINI_MODEL = "gemini-3.8-flash"

        private const val KEY_MODE = "mode"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_DEVICE_NAME = "device_name"
        private const val KEY_SERVER_PORT = "server_port"
        private const val KEY_GEMINI_MODEL = "gemini_model"
        private const val KEY_USE_MOCK = "use_mock_ai"
        private const val KEY_PAIRED_SERVER_ID = "paired_server_id"
        private const val KEY_PAIRED_SERVER_NAME = "paired_server_name"
        private const val KEY_PAIRED_SERVER_HOST = "paired_server_host"
        private const val KEY_PAIRED_SERVER_PORT = "paired_server_port"
        private const val SECURE_GEMINI_KEY = "gemini_api_key"
        private const val SECURE_AGENT_TOKEN = "agent_session_token"
    }
}

data class PairedServer(
    val serverId: String,
    val serverName: String,
    val host: String,
    val port: Int,
    val sessionToken: String
)
