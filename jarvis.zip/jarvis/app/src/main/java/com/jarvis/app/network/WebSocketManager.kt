package com.jarvis.app.network

import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.embeddedServer
import io.ktor.server.routing.routing
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration.Companion.seconds

/**
 * Server telefonunda gömülü WebSocket sunucusu (Ktor CIO). Agent'lar ws://<ip>:<port>/ws adresine bağlanır.
 * Yerel ağda düz ws:// kullanılır; internet üzerinden kullanım için TLS (wss://) arkasına alınmalıdır.
 */
class WebSocketManager(private val handler: AgentSessionHandler) {

    private var stopper: (() -> Unit)? = null

    val isRunning: Boolean get() = stopper != null

    suspend fun start(port: Int) = withContext(Dispatchers.IO) {
        if (stopper != null) return@withContext
        val server = embeddedServer(CIO, port = port, host = "0.0.0.0") {
            install(WebSockets) {
                pingPeriod = 15.seconds
                timeout = 30.seconds
                maxFrameSize = MAX_FRAME_BYTES
                masking = false
            }
            routing {
                webSocket(PATH) { serve(this) }
            }
        }
        server.start(wait = false)
        stopper = { server.stop(gracePeriodMillis = 300, timeoutMillis = 1_000) }
    }

    suspend fun stop() = withContext(Dispatchers.IO) {
        val stop = stopper ?: return@withContext
        stopper = null
        try {
            stop()
        } catch (e: Exception) {
            // Sunucu zaten kapanmış olabilir; kapanış hatası kullanıcıya gösterilmez.
        }
    }

    private suspend fun serve(session: DefaultWebSocketServerSession) {
        val connection = KtorAgentConnection(session)
        var deviceId: String? = null
        try {
            val first = withTimeoutOrNull(HANDSHAKE_TIMEOUT_MS) {
                (session.incoming.receiveCatching().getOrNull() as? Frame.Text)?.readText()
            }
            if (first == null) {
                session.close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "handshake"))
                return
            }
            deviceId = handler.handshake(first, connection)
            if (deviceId == null) {
                session.close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "rejected"))
                return
            }
            for (frame in session.incoming) {
                if (frame is Frame.Text) handler.onMessage(deviceId, connection, frame.readText())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Bozuk bağlantı: oturum sessizce kapanır, cihaz çevrimdışı işaretlenir.
        } finally {
            deviceId?.let { handler.onClosed(it, connection) }
        }
    }

    private class KtorAgentConnection(private val session: DefaultWebSocketServerSession) : AgentConnection {
        override suspend fun send(text: String): Boolean = try {
            session.send(Frame.Text(text))
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }

        override suspend fun close(reason: String) {
            try {
                session.close(CloseReason(CloseReason.Codes.NORMAL, reason))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // zaten kapalı
            }
        }
    }

    companion object {
        const val PATH = "/ws"
        private const val HANDSHAKE_TIMEOUT_MS = 10_000L
        private const val MAX_FRAME_BYTES = 64L * 1024
    }
}
