package com.jarvis.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY pairedAt ASC")
    fun observeAll(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices ORDER BY pairedAt ASC")
    suspend fun getAll(): List<DeviceEntity>

    @Query("SELECT * FROM devices WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DeviceEntity?

    @Query("SELECT * FROM devices WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun getByName(name: String): DeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DeviceEntity)

    @Query("DELETE FROM devices WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE devices SET status = :status, lastSeen = :lastSeen WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, lastSeen: Long)

    @Query("UPDATE devices SET name = :name WHERE id = :id")
    suspend fun rename(id: String, name: String)

    @Query("UPDATE devices SET status = 'OFFLINE'")
    suspend fun markAllOffline()
}

@Dao
interface CommandHistoryDao {
    @Query("SELECT * FROM command_history ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<CommandHistoryEntity>>

    @Insert
    suspend fun insert(entity: CommandHistoryEntity): Long

    @Query("DELETE FROM command_history")
    suspend fun clear()
}

@Dao
interface SettingsDao {
    @Query("SELECT settingValue FROM settings WHERE settingKey = :key LIMIT 1")
    suspend fun get(key: String): String?

    @Query("SELECT settingValue FROM settings WHERE settingKey = :key LIMIT 1")
    fun observe(key: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: SettingsEntity)

    @Query("DELETE FROM settings WHERE settingKey = :key")
    suspend fun delete(key: String)
}
