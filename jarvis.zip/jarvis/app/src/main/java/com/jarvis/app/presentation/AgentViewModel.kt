package com.jarvis.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.AppContainer
import com.jarvis.app.network.AgentStatus
import com.jarvis.app.network.AgentUiState
import com.jarvis.app.service.JarvisConnectionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Agent modu: eşleşme, bağlantı durumu ve son çalıştırılan komutlar. */
class AgentViewModel(private val container: AppContainer) : ViewModel() {

    private val client = container.agentClient

    val state: StateFlow<AgentUiState> = client.state
    val recent: StateFlow<List<String>> = client.recent

    private val _deviceName = MutableStateFlow("")
    val deviceName: StateFlow<String> = _deviceName

    private val _formError = MutableStateFlow<String?>(null)
    val formError: StateFlow<String?> = _formError

    init {
        viewModelScope.launch {
            _deviceName.value = container.settings.getDeviceName()
            client.refreshPairedState()
        }
        // Bağlantı kurulamadı/kesildi ise "bağlı" bildirimi kalmasın.
        viewModelScope.launch {
            client.state.collect { ui ->
                if (ui.status == AgentStatus.IDLE) JarvisConnectionService.stop(container.context)
            }
        }
    }

    fun pair(host: String, port: String, code: String) {
        val portNumber = port.toIntOrNull()
        when {
            host.isBlank() -> _formError.value = "Server adresini girin."
            portNumber == null || portNumber !in 1..65535 -> _formError.value = "Geçerli bir port girin."
            code.isBlank() -> _formError.value = "Eşleştirme kodunu girin."
            else -> {
                _formError.value = null
                JarvisConnectionService.start(container.context, JarvisConnectionService.ROLE_AGENT)
                client.pair(host, portNumber, code)
            }
        }
    }

    fun connect() {
        JarvisConnectionService.start(container.context, JarvisConnectionService.ROLE_AGENT)
        client.connect()
    }

    fun disconnect() {
        client.disconnect()
        JarvisConnectionService.stop(container.context)
    }

    fun forgetServer() {
        client.forgetServer()
        JarvisConnectionService.stop(container.context)
    }
}
