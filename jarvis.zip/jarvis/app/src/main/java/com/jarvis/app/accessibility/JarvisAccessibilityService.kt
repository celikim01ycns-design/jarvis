package com.jarvis.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Kullanıcı Ayarlar > Erişilebilirlik'ten kendisi açtığında çalışır; JARVIS bunu gizlice etkinleştirmez.
 * İlk sürümde ekran içeriğini okumaz ve olay işlemez (canRetrieveWindowContent=false).
 * İki işe yarar:
 *  1) Sistem tarafından bağlı olduğu için arka plandayken uygulama başlatma kısıtından muaftır (AppLauncher kullanır).
 *  2) İleride geri/ana ekran gibi temel eylemler için hazır giriş noktası sağlar.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bilinçli olarak boş: ilk sürümde ekran olayları işlenmez.
    }

    override fun onInterrupt() {
        // Geri bildirim kesintisi için yapılacak bir şey yok.
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        /** Kullanıcı hizmeti Ayarlar'dan etkinleştirdi mi? */
        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, JarvisAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ).orEmpty()
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }
    }
}
