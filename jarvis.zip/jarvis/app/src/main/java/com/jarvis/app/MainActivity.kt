package com.jarvis.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jarvis.app.data.AppMode
import com.jarvis.app.presentation.AgentViewModel
import com.jarvis.app.presentation.JarvisNavHost
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.MainViewModel
import com.jarvis.app.presentation.ModeState
import com.jarvis.app.presentation.screens.ModeSelectScreen
import com.jarvis.app.presentation.theme.JarvisColors
import com.jarvis.app.presentation.theme.JarvisTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as JarvisApp).container
        setContent {
            JarvisTheme {
                JarvisRoot(container)
            }
        }
    }
}

@Composable
private fun JarvisRoot(container: AppContainer) {
    val mainVm: MainViewModel = viewModel(factory = viewModelFactory { initializer { MainViewModel(container) } })
    val mode by mainVm.modeState.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current

    // Android 13+: kalıcı bağlantı bildirimini görebilmek için bildirim izni istenir.
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    when (val state = mode) {
        ModeState.Loading -> Box(Modifier.fillMaxSize().background(JarvisColors.Background), Alignment.Center) {
            CircularProgressIndicator()
        }
        ModeState.Unset -> Box(Modifier.fillMaxSize().background(JarvisColors.Background)) {
            ModeSelectScreen(onPick = mainVm::setMode)
        }
        is ModeState.Selected -> key(state.mode) {
            val jarvisVm: JarvisViewModel = viewModel(factory = viewModelFactory { initializer { JarvisViewModel(container) } })
            // AgentViewModel yalnızca Agent modunda oluşturulur: Server modunda Agent durumu hiç gözlenmez.
            val agentVm: AgentViewModel? = if (state.mode == AppMode.AGENT) {
                viewModel(factory = viewModelFactory { initializer { AgentViewModel(container) } })
            } else null
            JarvisNavHost(
                mode = state.mode,
                jarvisVm = jarvisVm,
                agentVm = agentVm,
                onSwitchMode = mainVm::setMode
            )
        }
    }
}
