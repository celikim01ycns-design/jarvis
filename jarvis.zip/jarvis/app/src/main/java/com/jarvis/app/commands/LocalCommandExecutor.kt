package com.jarvis.app.commands

import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.domain.LOCAL_TARGET

/** LOCAL hedefli eylemleri bu cihazda çalıştırır. Hem Server hem Agent kullanır. */
class LocalCommandExecutor(
    private val appOpener: AppOpener,
    private val devicesProvider: () -> List<DeviceInfo>,
    private val statusProvider: () -> String
) : CommandExecutor {

    override suspend fun execute(action: JarvisAction): CommandResult = when (action) {
        is JarvisAction.OpenApp ->
            if (action.target.equals(LOCAL_TARGET, ignoreCase = true)) {
                appOpener.open(action.app)
            } else {
                CommandResult.fail("Bu işlem yalnızca bu cihaz için çalıştırılabilir.")
            }

        is JarvisAction.GetDevices -> {
            val devices = devicesProvider()
            if (devices.isEmpty()) {
                CommandResult.ok("Kayıtlı cihaz yok.")
            } else {
                val text = devices.joinToString(", ") { d ->
                    "${d.name} (${if (d.online) "çevrimiçi" else "çevrimdışı"})"
                }
                CommandResult.ok("Cihazlar: $text")
            }
        }

        is JarvisAction.DeviceStatus -> CommandResult.ok(statusProvider())

        is JarvisAction.SendToDevice,
        is JarvisAction.Invalid,
        is JarvisAction.Unsupported ->
            CommandResult.fail("Bu işlem bu cihazda çalıştırılamaz.")
    }
}
