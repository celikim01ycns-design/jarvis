package com.jarvis.app.commands

import com.jarvis.app.domain.ActionValidator
import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.domain.ValidationResult
import kotlinx.coroutines.CancellationException

/**
 * Hattın son halkası: eylemi doğrular, yerel ya da uzak yürütücüye yönlendirir
 * ve kullanıcıya gösterilecek sonuç metnini üretir.
 */
class CommandRouter(
    private val validator: ActionValidator,
    private val local: CommandExecutor,
    private val remote: CommandExecutor,
    private val devicesProvider: () -> List<DeviceInfo>
) {

    suspend fun route(action: JarvisAction): CommandResult {
        val devices = devicesProvider()
        return when (val validation = validator.validate(action, devices)) {
            is ValidationResult.Rejected -> CommandResult.fail(validation.message)
            is ValidationResult.Ok -> run(validation.action, devices)
        }
    }

    private suspend fun run(action: JarvisAction, devices: List<DeviceInfo>): CommandResult {
        return try {
            if (action is JarvisAction.SendToDevice) {
                val device = devices.firstOrNull { it.id == action.deviceId }
                decorate(remote.execute(action), device?.name)
            } else {
                local.execute(action)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CommandResult.fail("Komut çalıştırılırken bir hata oluştu.")
        }
    }

    private fun decorate(result: CommandResult, deviceName: String?): CommandResult {
        if (deviceName == null || result.timedOut) return result
        return if (result.success) {
            result.copy(message = "$deviceName cihazında ${result.message}")
        } else {
            result.copy(message = "$deviceName: ${result.message}")
        }
    }
}
