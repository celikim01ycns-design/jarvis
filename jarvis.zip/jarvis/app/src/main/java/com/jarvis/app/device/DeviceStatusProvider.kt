package com.jarvis.app.device

import android.content.Context
import android.os.BatteryManager
import android.os.Build

/** Bu cihazın kısa durum metni (device_status komutunun cevabı). */
class DeviceStatusProvider(private val context: Context) {

    fun describe(): String {
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = battery?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val batteryText = if (level in 0..100) "pil %$level" else "pil bilgisi yok"
        return "Çevrimiçi, $batteryText, Android ${Build.VERSION.RELEASE}"
    }
}
