package com.jarvis.app.ai

import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.domain.LOCAL_TARGET
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.util.UUID

/** Gemini'ye gönderilen fonksiyon (tool) tanımları, sistem talimatı ve dönen çağrının eyleme çevrilmesi. */
object GeminiTools {

    private fun stringProp(description: String) = buildJsonObject {
        put("type", "string")
        put("description", description)
    }

    private fun function(
        name: String,
        description: String,
        properties: Map<String, JsonObject>,
        required: List<String>
    ): JsonObject = buildJsonObject {
        put("type", "function")
        put("name", name)
        put("description", description)
        put("parameters", buildJsonObject {
            put("type", "object")
            put("properties", JsonObject(properties))
            put("required", buildJsonArray { required.forEach { add(JsonPrimitive(it)) } })
        })
    }

    private val targetProp = stringProp(
        "Hedef cihazın adı (ör. 'Telefon B'). Kullanıcı cihaz belirtmediyse veya 'bu telefon' dediyse 'LOCAL'."
    )
    private val appProp = stringProp("Uygulamanın kullanıcının söylediği adı (ör. 'WhatsApp', 'Ayarlar').")

    /** Tüm tool'lar tanımlıdır; ilk sürümde yalnızca ilk dördü çalıştırılır, diğerleri nazikçe reddedilir. */
    val declarations: JsonArray = buildJsonArray {
        add(function("open_app", "Bir cihazda uygulama açar.", mapOf("target" to targetProp, "app" to appProp), listOf("target", "app")))
        add(function("close_app", "Bir cihazda uygulamayı kapatır.", mapOf("target" to targetProp, "app" to appProp), listOf("target", "app")))
        add(
            function(
                "send_to_device",
                "Komutu adı verilen başka bir cihaza gönderir.",
                mapOf(
                    "device" to stringProp("Hedef cihazın adı."),
                    "command" to buildJsonObject {
                        put("type", "string")
                        put("description", "Gönderilecek komut türü.")
                        put("enum", buildJsonArray { add(JsonPrimitive("open_app")); add(JsonPrimitive("device_status")) })
                    },
                    "app" to appProp
                ),
                listOf("device", "command")
            )
        )
        add(function("get_devices", "Kayıtlı cihazları ve çevrimiçi durumlarını listeler.", emptyMap(), emptyList()))
        add(function("device_status", "Bir cihazın durumunu (pil vb.) sorar.", mapOf("target" to targetProp), listOf("target")))
        for ((name, desc) in listOf(
            "play_media" to "Medyayı oynatır.",
            "pause_media" to "Medyayı duraklatır.",
            "next_media" to "Sonraki parçaya geçer.",
            "previous_media" to "Önceki parçaya döner."
        )) {
            add(function(name, desc, mapOf("target" to targetProp), listOf("target")))
        }
    }

    fun systemInstruction(devices: List<DeviceInfo>): String {
        val list = devices.filter { it.type == DeviceType.AGENT }
            .joinToString("\n") { "- ${it.name} (${if (it.online) "çevrimiçi" else "çevrimdışı"})" }
            .ifEmpty { "- (kayıtlı uzak cihaz yok)" }
        return """
            Sen JARVIS'sin: Android cihazları yöneten bir komut çözümleyicisin. Kullanıcı Türkçe konuşur.
            Yalnızca sana verilen fonksiyonlardan birini çağırarak yanıt ver; asla kendi başına bir işlem yapmış gibi davranma.
            Gerçek işlemi Android uygulaması yapar, sen sadece yapılandırılmış eylem üretirsin.

            Kurallar:
            - LOCAL, komutu veren ana cihazdır (Server).
            - Kullanıcı belirli bir cihaz adı söylerse target olarak o adı yaz.
            - Cihaz adı yoksa target "LOCAL" olsun.
            - Aşağıdaki listede olmayan bir cihaz adı söylenirse yine de söylenen adı yaz; uygulama bilinmeyen cihazı reddedecek.
            - Uygulama adını kullanıcının söylediği gibi yaz, paket adı uydurma.
            - Komut bir cihaz/uygulama işlemi değilse hiçbir fonksiyon çağırma.

            Bilinen uzak cihazlar:
            $list
        """.trimIndent()
    }

    /** Modelin fonksiyon çağrısını doğrudan Android koduna değil, doğrulanacak bir [JarvisAction]'a çevirir. */
    fun toAction(name: String, args: JsonObject): JarvisAction {
        fun str(key: String): String = args[key]?.jsonPrimitive?.contentOrNull?.trim().orEmpty()
        val target = str("target").ifEmpty { LOCAL_TARGET }
        return when (name) {
            "open_app" -> {
                val app = str("app")
                if (app.isEmpty()) JarvisAction.Invalid("Hangi uygulamanın açılacağı belirtilmedi.")
                else JarvisAction.OpenApp(target, app)
            }
            "send_to_device" -> {
                val device = str("device").ifEmpty { target }
                when (str("command").ifEmpty { "open_app" }) {
                    "open_app" -> {
                        val app = str("app")
                        if (app.isEmpty()) JarvisAction.Invalid("Hangi uygulamanın açılacağı belirtilmedi.")
                        else JarvisAction.OpenApp(device, app)
                    }
                    "device_status" -> JarvisAction.DeviceStatus(device)
                    else -> JarvisAction.Unsupported("send_to_device")
                }
            }
            "get_devices" -> JarvisAction.GetDevices(UUID.randomUUID().toString())
            "device_status" -> JarvisAction.DeviceStatus(target)
            "close_app", "play_media", "pause_media", "next_media", "previous_media" ->
                JarvisAction.Unsupported(name)
            else -> JarvisAction.Invalid("Komutu anlayamadım.")
        }
    }

    /**
     * Interactions API yanıtından ilk function_call adımını bulur (yanıt "steps" dizisinde gelir;
     * eski biçim için "outputs" da taranır). Bulunamazsa null.
     */
    fun extractCall(response: JsonObject): Pair<String, JsonObject>? {
        for (key in listOf("steps", "outputs")) {
            val items = response[key] as? JsonArray ?: continue
            for (item in items) {
                val obj = item as? JsonObject ?: continue
                if (obj["type"]?.jsonPrimitive?.contentOrNull != "function_call") continue
                val name = obj["name"]?.jsonPrimitive?.contentOrNull ?: continue
                val args = (obj["arguments"] ?: obj["args"]) as? JsonObject ?: JsonObject(emptyMap())
                return name to args
            }
        }
        return null
    }

    fun parseResponse(body: String, json: kotlinx.serialization.json.Json): JarvisAction {
        val root = json.parseToJsonElement(body).jsonObject
        val call = extractCall(root) ?: return JarvisAction.Invalid("Komutu anlayamadım.")
        return toAction(call.first, call.second)
    }
}
