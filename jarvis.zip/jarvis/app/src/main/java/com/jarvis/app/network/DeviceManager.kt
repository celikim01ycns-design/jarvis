package com.jarvis.app.network

import com.jarvis.app.commands.DeviceCommandSender
import com.jarvis.app.data.local.DeviceDao
import com.jarvis.app.data.local.DeviceEntity
import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.DeviceType
import com.jarvis.app.domain.TurkishText
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Bir Agent ile açık olan bağlantı (gerçekte Ktor WebSocket oturumu). */
interface AgentConnection {
    /** Mesaj gönderilebildiyse true. */
    suspend fun send(text: String): Boolean
    suspend fun close(reason: String)
}

/**
 * İletilemeyen komutlar için kanca. Şimdilik komut kaybolmaz ama kuyruğa da alınmaz
 * (geçmişe "çevrimdışı" olarak yazılır). İleride çevrimdışı kuyruk eklemek için buraya
 * bir uygulama takılır; DeviceManager değişmez.
 */
fun interface UndeliveredCommandSink {
    suspend fun onUndelivered(deviceId: String, payload: ActionPayload)
}

/**
 * Server'da cihaz kaydı, çevrimiçi durumu ve komut gönderimi. Her komuta UUID verilir,
 * [commandTimeoutMs] içinde yanıt gelmezse "yanıt vermiyor" sonucu döner.
 */
class DeviceManager(
    private val dao: DeviceDao,
    private val clock: () -> Long = System::currentTimeMillis,
    private val commandTimeoutMs: Long = DEFAULT_COMMAND_TIMEOUT_MS,
    private val undelivered: UndeliveredCommandSink = UndeliveredCommandSink { _, _ -> }
) : DeviceCommandSender {

    private class Pending(val deviceId: String, val result: CompletableDeferred<CommandResultMessage>)

    private val mutex = Mutex()
    private val connections = ConcurrentHashMap<String, AgentConnection>()
    private val pending = ConcurrentHashMap<String, Pending>()

    @Volatile
    private var serverId: String = ""

    @Volatile
    private var serverName: String = ""

    private val _devices = MutableStateFlow<List<DeviceInfo>>(emptyList())

    /** Server'ın kendisi (SERVER) + kayıtlı Agent'lar. Çevrimiçi durumu bağlantılardan gelir. */
    val devices: StateFlow<List<DeviceInfo>> = _devices

    fun serverId(): String = serverId

    fun serverName(): String = serverName

    suspend fun setServerIdentity(id: String, name: String) {
        serverId = id
        serverName = name
        publish()
    }

    /** Uygulama açılışında: tüm cihazlar çevrimdışı başlar, bağlantılar kuruldukça çevrimiçi olur. */
    suspend fun load() {
        dao.markAllOffline()
        publish()
    }

    fun getAllDevices(): List<DeviceInfo> = _devices.value

    fun getDevice(id: String): DeviceInfo? = _devices.value.firstOrNull { it.id == id }

    fun isOnline(id: String): Boolean = connections.containsKey(id)

    /**
     * Yeni eşleşen cihazı kaydeder. İsim benzersiz olmak zorundadır: çakışırsa "Ad (2)" verilir.
     * Aynı id ile yeniden eşleşme mevcut kaydı (ve eski token'ı) değiştirir.
     */
    suspend fun addDevice(id: String, requestedName: String, tokenHash: String): DeviceInfo {
        val now = clock()
        val name = uniqueName(requestedName.trim().ifEmpty { "Android Telefon" }.take(MAX_NAME), excludeId = id)
        val previous = dao.getById(id)
        dao.upsert(
            DeviceEntity(
                id = id,
                name = name,
                type = DeviceType.AGENT.name,
                status = STATUS_OFFLINE,
                createdAt = previous?.createdAt ?: now,
                lastSeen = now,
                pairedAt = now,
                tokenHash = tokenHash
            )
        )
        publish()
        return DeviceInfo(id, name, DeviceType.AGENT, online = false, lastSeen = now)
    }

    /** Cihazı siler, bağlantısını kapatır; token artık geçersizdir. */
    suspend fun removeDevice(id: String) {
        connections.remove(id)?.let { conn ->
            conn.send(CommandProtocol.encode(Disconnect("Cihaz Server'dan kaldırıldı.")))
            conn.close("removed")
        }
        failPending(id, "Cihaz kaldırıldı.")
        dao.delete(id)
        publish()
    }

    /** Agent'ı kaldırmadan bağlantısını keser; Agent kendiliğinden yeniden bağlanmaz. */
    suspend fun disconnect(id: String) {
        val conn = connections[id] ?: return
        conn.send(CommandProtocol.encode(Disconnect("Server bağlantıyı kesti.")))
        conn.close("disconnected")
    }

    /** İsim boşsa ya da başka bir cihazla çakışıyorsa false. */
    suspend fun renameDevice(id: String, newName: String): Boolean {
        val name = newName.trim().take(MAX_NAME)
        if (name.isEmpty()) return false
        if (nameTaken(name, excludeId = id)) return false
        if (dao.getById(id) == null) return false
        dao.rename(id, name)
        publish()
        return true
    }

    suspend fun verifyToken(id: String, tokenHash: String): Boolean {
        val entity = dao.getById(id) ?: return false
        return MessageDigest.isEqual(
            entity.tokenHash.toByteArray(Charsets.UTF_8),
            tokenHash.toByteArray(Charsets.UTF_8)
        )
    }

    suspend fun onAgentConnected(id: String, connection: AgentConnection) {
        val old = connections.put(id, connection)
        if (old != null && old !== connection) old.close("replaced")
        dao.updateStatus(id, STATUS_ONLINE, clock())
        publish()
    }

    suspend fun onAgentDisconnected(id: String, connection: AgentConnection) {
        // Aynı cihaz yeniden bağlandıysa eski oturumun kapanışı yenisini düşürmemeli.
        if (!connections.remove(id, connection)) return
        failPending(id, "Bağlantı koptu.")
        dao.updateStatus(id, STATUS_OFFLINE, clock())
        publish()
    }

    suspend fun disconnectAll() {
        val snapshot = connections.entries.toList()
        connections.clear()
        snapshot.forEach { (id, conn) ->
            failPending(id, "Server durduruldu.")
            conn.close("server stopped")
        }
        dao.markAllOffline()
        publish()
    }

    /** Agent'tan gelen sonucu bekleyen komuta iletir. Başka cihazın komutuna yanıt verilemez. */
    fun onCommandResult(fromDeviceId: String, message: CommandResultMessage) {
        val entry = pending[message.commandId] ?: return
        if (entry.deviceId != fromDeviceId) return
        entry.result.complete(message)
    }

    suspend fun touch(id: String) {
        dao.updateStatus(id, STATUS_ONLINE, clock())
    }

    override suspend fun send(deviceId: String, payload: ActionPayload): CommandResult = sendCommand(deviceId, payload)

    suspend fun sendCommand(deviceId: String, payload: ActionPayload): CommandResult {
        val device = getDevice(deviceId) ?: return CommandResult.fail("Bilinmeyen cihaz.")
        val connection = connections[deviceId]
        if (connection == null) {
            undelivered.onUndelivered(deviceId, payload)
            return CommandResult.fail("${device.name} şu anda çevrimdışı.")
        }

        val command = CommandProtocol.newCommand(serverId, deviceId, payload, clock())
        val entry = Pending(deviceId, CompletableDeferred())
        pending[command.commandId] = entry
        try {
            if (!connection.send(CommandProtocol.encode(command))) {
                undelivered.onUndelivered(deviceId, payload)
                return CommandResult.fail("${device.name} şu anda çevrimdışı.")
            }
            val reply = withTimeoutOrNull(commandTimeoutMs) { entry.result.await() }
                ?: return CommandResult.timeout("${device.name} yanıt vermiyor.")
            return CommandResult(reply.success, reply.message)
        } finally {
            pending.remove(command.commandId)
        }
    }

    private fun failPending(deviceId: String, reason: String) {
        pending.values.filter { it.deviceId == deviceId }.forEach {
            it.result.complete(CommandResultMessage(commandId = "", success = false, message = reason))
        }
    }

    private suspend fun publish() {
        mutex.withLock {
            val agents = dao.getAll().map { e ->
                DeviceInfo(
                    id = e.id,
                    name = e.name,
                    type = DeviceType.AGENT,
                    online = connections.containsKey(e.id),
                    lastSeen = e.lastSeen
                )
            }
            val list = buildList {
                if (serverId.isNotEmpty()) {
                    add(DeviceInfo(serverId, serverName, DeviceType.SERVER, online = true, lastSeen = clock()))
                }
                addAll(agents)
            }
            _devices.value = list
        }
    }

    private suspend fun nameTaken(name: String, excludeId: String?): Boolean {
        val key = TurkishText.compact(name)
        if (serverName.isNotEmpty() && TurkishText.compact(serverName) == key) return true
        return dao.getAll().any { it.id != excludeId && TurkishText.compact(it.name) == key }
    }

    private suspend fun uniqueName(base: String, excludeId: String?): String {
        if (!nameTaken(base, excludeId)) return base
        var n = 2
        while (nameTaken("$base ($n)", excludeId)) n++
        return "$base ($n)"
    }

    companion object {
        const val DEFAULT_COMMAND_TIMEOUT_MS = 10_000L
        const val STATUS_ONLINE = "ONLINE"
        const val STATUS_OFFLINE = "OFFLINE"
        private const val MAX_NAME = 40
    }
}
