package com.jarvis.app.domain

sealed class ValidationResult {
    data class Ok(val action: JarvisAction) : ValidationResult()
    data class Rejected(val message: String) : ValidationResult()
}

/**
 * Yapay zekâdan gelen eylemi çalıştırmadan önce doğrular:
 * bilinmeyen cihaz, çevrimdışı cihaz, boş uygulama adı ve desteklenmeyen eylemler burada elenir.
 * Uzak hedefler SendToDevice(deviceId, ...) biçimine dönüştürülür.
 */
class ActionValidator {

    private sealed class Target {
        object Local : Target()
        data class Remote(val device: DeviceInfo) : Target()
        object Unknown : Target()
    }

    fun validate(action: JarvisAction, devices: List<DeviceInfo>): ValidationResult = when (action) {
        is JarvisAction.OpenApp -> validateOpenApp(action, devices)
        is JarvisAction.SendToDevice -> validateSend(action, devices)
        is JarvisAction.GetDevices -> ValidationResult.Ok(action)
        is JarvisAction.DeviceStatus -> validateStatus(action, devices)
        is JarvisAction.Invalid -> ValidationResult.Rejected(action.reason)
        is JarvisAction.Unsupported ->
            ValidationResult.Rejected("Bu eylem ilk sürümde desteklenmiyor.")
    }

    private fun validateOpenApp(action: JarvisAction.OpenApp, devices: List<DeviceInfo>): ValidationResult {
        if (action.app.isBlank()) {
            return ValidationResult.Rejected("Hangi uygulamanın açılacağı belirtilmedi.")
        }
        return when (val target = resolve(action.target, devices)) {
            Target.Local -> ValidationResult.Ok(JarvisAction.OpenApp(LOCAL_TARGET, action.app.trim()))
            Target.Unknown -> ValidationResult.Rejected(unknownDevice(action.target))
            is Target.Remote -> {
                if (!target.device.online) {
                    ValidationResult.Rejected("${target.device.name} şu anda çevrimdışı.")
                } else {
                    ValidationResult.Ok(
                        JarvisAction.SendToDevice(
                            deviceId = target.device.id,
                            action = JarvisAction.OpenApp(target.device.name, action.app.trim())
                        )
                    )
                }
            }
        }
    }

    private fun validateStatus(action: JarvisAction.DeviceStatus, devices: List<DeviceInfo>): ValidationResult {
        return when (val target = resolve(action.target, devices)) {
            Target.Local -> ValidationResult.Ok(JarvisAction.DeviceStatus(LOCAL_TARGET))
            Target.Unknown -> ValidationResult.Rejected(unknownDevice(action.target))
            is Target.Remote -> {
                if (!target.device.online) {
                    ValidationResult.Rejected("${target.device.name} şu anda çevrimdışı.")
                } else {
                    ValidationResult.Ok(
                        JarvisAction.SendToDevice(target.device.id, JarvisAction.DeviceStatus(LOCAL_TARGET))
                    )
                }
            }
        }
    }

    private fun validateSend(action: JarvisAction.SendToDevice, devices: List<DeviceInfo>): ValidationResult {
        val device = devices.firstOrNull { it.id == action.deviceId && it.type == DeviceType.AGENT }
            ?: return ValidationResult.Rejected("Bilinmeyen cihaz.")
        if (!device.online) return ValidationResult.Rejected("${device.name} şu anda çevrimdışı.")
        return when (val inner = action.action) {
            is JarvisAction.OpenApp ->
                if (inner.app.isBlank()) ValidationResult.Rejected("Hangi uygulamanın açılacağı belirtilmedi.")
                else ValidationResult.Ok(action)
            is JarvisAction.DeviceStatus -> ValidationResult.Ok(action)
            else -> ValidationResult.Rejected("Bu eylem uzak cihaza gönderilemez.")
        }
    }

    private fun resolve(target: String, devices: List<DeviceInfo>): Target {
        val norm = TurkishText.normalize(target)
        if (norm.isEmpty() || norm == "local" || norm == "bu telefon" || norm == "bu cihaz") return Target.Local

        val servers = devices.filter { it.type == DeviceType.SERVER }
        if (servers.any { TurkishText.normalize(it.name) == norm }) return Target.Local

        val compact = TurkishText.compact(target)
        val agent = devices.firstOrNull {
            it.type == DeviceType.AGENT &&
                (TurkishText.normalize(it.name) == norm || TurkishText.compact(it.name) == compact)
        }
        return if (agent != null) Target.Remote(agent) else Target.Unknown
    }

    private fun unknownDevice(target: String) = "\"$target\" adlı bir cihaz bulunamadı."
}
