package com.jarvis.app.commands

import com.jarvis.app.domain.CommandResult
import com.jarvis.app.domain.JarvisAction
import com.jarvis.app.network.toPayload

/** SendToDevice eylemini komut protokolüne çevirip Agent'a iletir; sonucu bekler. */
class RemoteCommandExecutor(
    private val sender: DeviceCommandSender
) : CommandExecutor {

    override suspend fun execute(action: JarvisAction): CommandResult {
        if (action !is JarvisAction.SendToDevice) {
            return CommandResult.fail("Bu işlem uzak cihaza gönderilemez.")
        }
        val payload = action.action.toPayload()
            ?: return CommandResult.fail("Bu eylem uzak cihaza gönderilemez.")
        return sender.send(action.deviceId, payload)
    }
}
