package com.jarvis.app.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors

@Composable
fun HistoryScreen(vm: JarvisViewModel, onBack: () -> Unit) {
    val history by vm.history.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = JarvisColors.Background,
        topBar = {
            JarvisTopBar("Komut geçmişi", onBack) {
                IconButton(onClick = vm::clearHistory, enabled = history.isNotEmpty()) {
                    Icon(Icons.Filled.DeleteSweep, "Geçmişi temizle")
                }
            }
        }
    ) { padding ->
        if (history.isEmpty()) {
            Text("Henüz komut yok.", color = JarvisColors.Muted, modifier = Modifier.padding(padding).padding(24.dp))
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history, key = { it.id }) { item ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(JarvisColors.Surface).padding(14.dp)
                    ) {
                        Text(item.commandText, style = MaterialTheme.typography.titleSmall)
                        Text(
                            (if (item.success) "✓ " else "✗ ") + item.result,
                            color = if (item.success) JarvisColors.Online else JarvisColors.Error
                        )
                        Text(
                            "${item.actionType} · ${item.targetDevice} · ${formatLastSeen(item.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = JarvisColors.Muted
                        )
                    }
                }
            }
        }
    }
}
