package com.jarvis.app.ai

import com.jarvis.app.domain.DeviceInfo
import com.jarvis.app.domain.JarvisAction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Gemini Interactions API (REST, v1beta) ile function calling. Eski `generativeai` SDK'sı kullanılmaz;
 * ek SDK bağımlılığı yerine OkHttp + kotlinx.serialization yeterlidir.
 *
 * İstek: POST {endpoint} — başlık x-goog-api-key, gövde {model, input, system_instruction, tools[], store}.
 * Yanıt: Interaction kaynağı; "steps" içindeki {"type":"function_call","name":...,"arguments":{...}}.
 * Tek turda yalnızca eylem üretilir, sonuç modele geri gönderilmez (function_result gerekmez).
 *
 * API anahtarı ve model adı çağrı anında okunur; anahtar hiçbir zaman kaynak koda yazılmaz.
 */
class GeminiServiceImpl(
    private val client: OkHttpClient,
    private val apiKeyProvider: () -> String,
    private val modelProvider: suspend () -> String,
    private val endpoint: String = DEFAULT_ENDPOINT
) : GeminiService {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun processCommand(userCommand: String, devices: List<DeviceInfo>): JarvisAction {
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isEmpty()) {
            throw GeminiException("Gemini API anahtarı girilmemiş. Ayarlar'dan ekleyin ya da Mock modunu kullanın.")
        }
        val model = modelProvider().trim().ifEmpty { throw GeminiException("Gemini model adı boş.") }

        val body = buildJsonObject {
            put("model", model)
            put("input", userCommand)
            put("system_instruction", GeminiTools.systemInstruction(devices))
            put("tools", GeminiTools.declarations)
            put("store", false)
        }.toString()

        val request = Request.Builder()
            .url(endpoint)
            .header("x-goog-api-key", apiKey)
            .post(body.toRequestBody(JSON_MEDIA))
            .build()

        return try {
            withContext(Dispatchers.IO) {
                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw GeminiException(messageForStatus(response.code))
                    }
                    GeminiTools.parseResponse(text, json)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiException) {
            throw e
        } catch (e: IOException) {
            throw GeminiException("JARVIS AI servisine bağlanılamadı.", e)
        } catch (e: Exception) {
            throw GeminiException("JARVIS AI yanıtı anlaşılamadı.", e)
        }
    }

    private fun messageForStatus(code: Int): String = when (code) {
        400 -> "JARVIS AI isteği reddetti. Model adını ve API anahtarını kontrol edin."
        401, 403 -> "Gemini API anahtarı geçersiz veya yetkisiz."
        404 -> "Gemini modeli bulunamadı. Ayarlar'dan model adını kontrol edin."
        429 -> "Gemini kullanım sınırına ulaşıldı. Biraz sonra tekrar deneyin."
        else -> "JARVIS AI servisine bağlanılamadı."
    }

    companion object {
        const val DEFAULT_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }
}
