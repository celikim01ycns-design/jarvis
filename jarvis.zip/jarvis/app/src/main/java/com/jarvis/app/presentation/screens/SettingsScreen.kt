package com.jarvis.app.presentation.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.accessibility.JarvisAccessibilityService
import com.jarvis.app.data.AppMode
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors

@Composable
fun SettingsScreen(vm: JarvisViewModel, mode: AppMode, onBack: () -> Unit, onSwitchMode: (AppMode) -> Unit) {
    val context = LocalContext.current
    val ui by vm.settingsUi.collectAsStateWithLifecycle()

    var name by remember(ui.deviceName) { mutableStateOf(ui.deviceName) }
    var port by remember(ui.port) { mutableStateOf(ui.port.toString()) }
    var model by remember(ui.geminiModel) { mutableStateOf(ui.geminiModel) }
    var useMock by remember(ui.useMockAi) { mutableStateOf(ui.useMockAi) }
    var apiKey by remember { mutableStateOf("") }
    var accessibilityOn by remember { mutableStateOf(JarvisAccessibilityService.isEnabled(context)) }

    LifecycleResumeEffect(Unit) {
        accessibilityOn = JarvisAccessibilityService.isEnabled(context)
        onPauseOrDispose { }
    }
    LaunchedEffect(Unit) { vm.loadSettings() }

    Scaffold(containerColor = JarvisColors.Background, topBar = { JarvisTopBar("Ayarlar", onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionTitle("Bu cihaz")
            OutlinedTextField(name, { name = it }, label = { Text("Cihaz adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            if (mode == AppMode.SERVER) {
                OutlinedTextField(
                    port, { port = it.filter(Char::isDigit) },
                    label = { Text("Server portu") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider()
                SectionTitle("Yapay zekâ (Gemini)")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Mock AI kullan")
                        Text("API anahtarı olmadan, kural tabanlı çalışır.", style = MaterialTheme.typography.bodySmall, color = JarvisColors.Muted)
                    }
                    Switch(useMock, { useMock = it })
                }
                OutlinedTextField(model, { model = it }, label = { Text("Gemini modeli") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    apiKey, { apiKey = it },
                    label = { Text(if (ui.hasApiKey) "API anahtarı (kayıtlı — değiştirmek için yazın)" else "Gemini API anahtarı") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Anahtar cihazda Android Keystore ile şifreli saklanır; kaynak koda yazılmaz.",
                    style = MaterialTheme.typography.bodySmall, color = JarvisColors.Muted
                )
                if (ui.hasApiKey) {
                    TextButton(onClick = vm::clearApiKey) { Text("Kayıtlı anahtarı sil") }
                }
            }

            Button(
                onClick = { vm.saveSettings(name, port.ifEmpty { ui.port.toString() }, model, useMock, apiKey); apiKey = "" },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kaydet") }
            ui.savedMessage?.let { Text(it, color = JarvisColors.Muted, style = MaterialTheme.typography.bodySmall) }

            HorizontalDivider()
            SectionTitle("Erişilebilirlik")
            Text(
                if (accessibilityOn) "JARVIS erişilebilirlik hizmeti açık."
                else "Kapalı. Uygulama arka plandayken uygulama açma komutlarının çalışması için gerekebilir. Yalnızca siz açarsanız etkinleşir.",
                color = if (accessibilityOn) JarvisColors.Online else JarvisColors.Muted,
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(
                onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Erişilebilirlik ayarlarını aç") }

            HorizontalDivider()
            SectionTitle("Mod")
            val other = if (mode == AppMode.SERVER) AppMode.AGENT else AppMode.SERVER
            OutlinedButton(onClick = { onSwitchMode(other) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (other == AppMode.AGENT) "Bu telefonu Agent yap" else "Bu telefonu Server yap")
            }
            Text("Mod değişince çalışan bağlantılar kapatılır.", style = MaterialTheme.typography.bodySmall, color = JarvisColors.Muted)
            androidx.compose.foundation.layout.Spacer(Modifier.padding(16.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = JarvisColors.Cyan, modifier = Modifier.padding(top = 8.dp))
}
