package com.jarvis.app.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.app.data.AppMode
import com.jarvis.app.presentation.theme.JarvisColors

@Composable
fun ModeSelectScreen(onPick: (AppMode) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("JARVIS", fontSize = 40.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp, color = JarvisColors.Cyan)
        Spacer(Modifier.height(32.dp))
        Text(
            "JARVIS'i nasıl kullanmak istiyorsun?",
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Server komutları alır ve cihazlara dağıtır. Agent, eşleştiği Server'ın izinli komutlarını çalıştırır.",
            style = MaterialTheme.typography.bodyMedium,
            color = JarvisColors.Muted,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = { onPick(AppMode.SERVER) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Bu telefonu Server yap")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { onPick(AppMode.AGENT) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Bu telefonu Agent yap")
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "Bu tercihi daha sonra Ayarlar'dan değiştirebilirsin.",
            style = MaterialTheme.typography.bodySmall,
            color = JarvisColors.Muted
        )
    }
}
