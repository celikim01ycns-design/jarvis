package com.jarvis.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "devices",
    indices = [Index(value = ["name"], unique = true)]
)
data class DeviceEntity(
    @PrimaryKey val id: String,
    val name: String,
    /** DeviceType adı: SERVER veya AGENT */
    val type: String,
    /** ONLINE veya OFFLINE */
    val status: String,
    val createdAt: Long,
    val lastSeen: Long,
    val pairedAt: Long,
    /** Oturum token'ının SHA-256 özeti; ham token Server'da saklanmaz. */
    val tokenHash: String
)

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commandText: String,
    val targetDevice: String,
    val actionType: String,
    val success: Boolean,
    val result: String,
    val timestamp: Long
)

/** Hassas olmayan ayarlar. Gizli değerler (API anahtarı, token) SecureStore'dadır. */
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val settingKey: String,
    val settingValue: String
)
