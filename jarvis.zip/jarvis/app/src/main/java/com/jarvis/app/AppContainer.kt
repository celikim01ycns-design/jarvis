package com.jarvis.app

import android.content.Context
import com.jarvis.app.ai.GeminiService
import com.jarvis.app.ai.GeminiServiceImpl
import com.jarvis.app.ai.MockGeminiService
import com.jarvis.app.commands.LocalCommandExecutor
import com.jarvis.app.data.SettingsRepository
import com.jarvis.app.data.local.JarvisDatabase
import com.jarvis.app.device.AppLauncher
import com.jarvis.app.device.AppRegistry
import com.jarvis.app.device.DeviceStatusProvider
import com.jarvis.app.device.InstalledAppsSource
import com.jarvis.app.network.AgentClient
import com.jarvis.app.network.DeviceManager
import com.jarvis.app.network.PairingManager
import com.jarvis.app.security.SecureStore
import com.jarvis.app.service.ServerController
import com.jarvis.app.voice.AndroidSpeechRecognizerService
import com.jarvis.app.voice.AndroidTextToSpeechService
import com.jarvis.app.voice.SpeechRecognizerService
import com.jarvis.app.voice.TextToSpeechService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Elle kurulan bağımlılık kapsayıcısı (ek DI kütüphanesi gerektirmez). */
class AppContainer(val context: Context) {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database: JarvisDatabase by lazy { JarvisDatabase.create(context) }
    val secureStore: SecureStore by lazy { SecureStore(context) }
    val settings: SettingsRepository by lazy { SettingsRepository(database.settingsDao(), secureStore) }

    val appRegistry: AppRegistry by lazy { AppRegistry { InstalledAppsSource.discover(context) } }
    val appLauncher: AppLauncher by lazy { AppLauncher(context, appRegistry) }
    private val statusProvider: DeviceStatusProvider by lazy { DeviceStatusProvider(context) }

    /** WebSocket için: okuma zaman aşımı yok, bağlantıyı canlı tutmak için 15 sn'de bir ping. */
    val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(15, TimeUnit.SECONDS)
            .build()
    }

    /** Gemini REST çağrısı için: kısa zaman aşımı, ping yok. */
    private val geminiHttpClient: OkHttpClient by lazy {
        httpClient.newBuilder()
            .readTimeout(20, TimeUnit.SECONDS)
            .callTimeout(25, TimeUnit.SECONDS)
            .pingInterval(0, TimeUnit.MILLISECONDS)
            .build()
    }

    val speechRecognizer: SpeechRecognizerService by lazy { AndroidSpeechRecognizerService(context) }
    val textToSpeech: TextToSpeechService by lazy { AndroidTextToSpeechService(context) }

    val pairingManager: PairingManager by lazy { PairingManager() }
    val deviceManager: DeviceManager by lazy { DeviceManager(database.deviceDao()) }

    val serverController: ServerController by lazy {
        ServerController(
            settings = settings,
            deviceManager = deviceManager,
            pairing = pairingManager,
            historyDao = database.commandHistoryDao(),
            appOpener = appLauncher,
            serverStatus = {
                val agents = deviceManager.getAllDevices().count { it.type == com.jarvis.app.domain.DeviceType.AGENT && it.online }
                "Server çalışıyor, $agents Agent çevrimiçi. ${statusProvider.describe()}"
            },
            aiProvider = ::selectAi
        )
    }

    val agentClient: AgentClient by lazy {
        AgentClient(
            http = httpClient,
            settings = settings,
            executor = LocalCommandExecutor(
                appOpener = appLauncher,
                devicesProvider = { emptyList() },
                statusProvider = { statusProvider.describe() }
            ),
            scope = appScope
        )
    }

    /** Mock açıksa ya da anahtar yoksa MockGeminiService; aksi halde gerçek Gemini. */
    private suspend fun selectAi(): GeminiService {
        if (settings.getUseMockAi() || !settings.hasGeminiApiKey()) return MockGeminiService()
        return GeminiServiceImpl(
            client = geminiHttpClient,
            apiKeyProvider = settings::getGeminiApiKey,
            modelProvider = settings::getGeminiModel
        )
    }

    /** Bildirimdeki "Bağlantıyı kes" ve ayarlardan mod değişimi: Server'ı durdurur, Agent'ı keser. */
    fun stopAll() {
        agentClient.disconnect()
        appScope.launch { serverController.stop() }
    }
}
