package com.jarvis.app.domain

import java.util.UUID

/**
 * Basit, kural tabanlı Türkçe komut ayrıştırıcı. MockGeminiService bunu kullanır; böylece
 * API anahtarı olmadan da uygulama uçtan uca test edilebilir.
 * Çıktı, gerçek Gemini'nin üreteceği yapılandırılmış eylemle aynı biçimdedir.
 */
object CommandParser {

    private val openVerbs = setOf("ac", "acar", "acin", "acsana", "baslat", "calistir", "open")
    private val closeVerbs = setOf("kapat", "kapatir", "kapatin", "kapatsana")
    private val fillers = setOf(
        "jarvis", "bu", "lutfen", "hemen", "simdi", "bana", "bir", "misin", "musun", "mi",
        "uygulama", "uygulamasi", "uygulamasini", "uygulamayi", "uygulamasina",
        "burada", "telefonda", "cihazda", "telefonu", "cihazi"
    )
    private val deviceKinds = setOf("telefon", "tablet", "cihaz")

    private class Tok(val orig: String, val norm: String) {
        val stem: String = TurkishText.stem(norm)
        val origStem: String = orig.substringBefore('\'').substringBefore('’')
    }

    fun parse(text: String, devices: List<DeviceInfo>): JarvisAction {
        val clean = text.trim()
        if (clean.isEmpty()) return JarvisAction.Invalid("Komut boş.")

        val toks = clean.split(Regex("\\s+")).mapNotNull { raw ->
            val orig = raw.trim('.', ',', '!', '?', ';', ':', '"')
            val norm = TurkishText.normalize(orig)
            if (norm.isEmpty()) null else Tok(orig, norm)
        }
        if (toks.isEmpty()) return JarvisAction.Invalid("Komut anlaşılamadı.")

        val whole = toks.joinToString(" ") { it.norm }

        if (whole.contains("cihazlar") || whole.contains("hangi cihaz")) {
            return JarvisAction.GetDevices(UUID.randomUUID().toString())
        }

        val (target, removed) = detectTarget(toks, devices)

        if (whole.contains("durum")) {
            return JarvisAction.DeviceStatus(target)
        }

        val hasOpen = toks.any { it.stem in openVerbs }
        val hasClose = toks.any { it.stem in closeVerbs }
        if (hasClose && !hasOpen) return JarvisAction.Unsupported("close_app")
        if (!hasOpen) return JarvisAction.Invalid("Komutu anlayamadım.")

        val appTokens = toks.filterIndexed { index, tok ->
            index !in removed &&
                tok.stem !in openVerbs &&
                tok.stem !in fillers
        }
        val app = appTokens.joinToString(" ") { it.origStem }.trim()
        if (app.isEmpty()) return JarvisAction.Invalid("Hangi uygulamayı açmamı istediğinizi anlayamadım.")

        return JarvisAction.OpenApp(target = target, app = app)
    }

    private fun detectTarget(toks: List<Tok>, devices: List<DeviceInfo>): Pair<String, Set<Int>> {
        val named = devices
            .filter { it.type == DeviceType.AGENT }
            .sortedByDescending { it.name.length }
        for (device in named) {
            val parts = TurkishText.normalize(device.name).split(' ').filter { it.isNotEmpty() }
            if (parts.isEmpty() || parts.size > toks.size) continue
            for (i in 0..(toks.size - parts.size)) {
                val matches = parts.indices.all { k ->
                    val tokStem = toks[i + k].stem
                    val isLast = k == parts.lastIndex
                    tokStem == parts[k] ||
                        (isLast && parts[k].length >= 3 && tokStem.startsWith(parts[k]))
                }
                if (matches) return device.name to (i until i + parts.size).toSet()
            }
        }

        // Kayıtlı olmayan bir cihaz anılıyorsa ("Telefon D'de ...") adı korunur ki doğrulayıcı reddedebilsin.
        for (i in 0 until toks.size - 1) {
            if (toks[i].norm in deviceKinds) {
                val next = toks[i + 1]
                if (next.stem !in openVerbs && next.stem !in closeVerbs && next.stem !in fillers) {
                    return "${toks[i].origStem} ${next.origStem}" to setOf(i, i + 1)
                }
            }
        }
        return LOCAL_TARGET to emptySet()
    }
}
