package com.jarvis.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.AppContainer
import com.jarvis.app.data.AppMode
import com.jarvis.app.service.JarvisConnectionService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ModeState {
    object Loading : ModeState
    object Unset : ModeState
    data class Selected(val mode: AppMode) : ModeState
}

/** İlk açılışta Server/Agent seçimi ve Ayarlar'dan mod değişimi. */
class MainViewModel(private val container: AppContainer) : ViewModel() {

    val modeState: StateFlow<ModeState> = container.settings.mode
        .map { mode -> if (mode == null) ModeState.Unset else ModeState.Selected(mode) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, ModeState.Loading)

    /** Mod değişirken çalışan Server/Agent durdurulur; yeni mod temiz başlar. */
    fun setMode(mode: AppMode) {
        viewModelScope.launch {
            container.stopAll()
            JarvisConnectionService.stop(container.context)
            container.settings.setMode(mode)
        }
    }
}
