package com.jarvis.app.device

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import com.jarvis.app.accessibility.JarvisAccessibilityService
import com.jarvis.app.commands.AppOpener
import com.jarvis.app.domain.CommandResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Uygulamayı PackageManager + launch intent ile açar. Accessibility gerektirmez.
 *
 * Not: Android 10+ arka plandan activity başlatmayı kısıtlar. Uygulama arka plandayken
 * (özellikle Agent) başlatabilmek için kullanıcının açıkça verdiği "Diğer uygulamaların
 * üzerinde göster" izni ya da etkinleştirdiği JARVIS erişilebilirlik hizmeti gerekir.
 */
class AppLauncher(
    private val context: Context,
    private val registry: AppRegistry
) : AppOpener {

    override suspend fun open(appName: String): CommandResult = withContext(Dispatchers.Main) {
        val app = registry.find(appName)
            ?: return@withContext CommandResult.fail("Bu cihazda $appName bulunamadı.")

        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return@withContext CommandResult.fail("${app.label} başlatılamıyor.")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        // Erişilebilirlik hizmeti sistem tarafından bağlandığı için arka plan kısıtından muaftır.
        val launchContext: Context = JarvisAccessibilityService.instance ?: context
        try {
            launchContext.startActivity(intent)
            CommandResult.ok("${app.label} açıldı")
        } catch (e: ActivityNotFoundException) {
            CommandResult.fail("${app.label} başlatılamıyor.")
        } catch (e: SecurityException) {
            CommandResult.fail("Bu işlem için gerekli Android izni verilmemiş.")
        }
    }
}
