package com.jarvis.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.Locale

sealed class SpeechEvent {
    object Listening : SpeechEvent()
    data class Partial(val text: String) : SpeechEvent()
    data class Final(val text: String) : SpeechEvent()
    data class Error(val message: String) : SpeechEvent()
}

/**
 * Konuşmayı metne çevirir. Soyutlama sayesinde ileride Gemini Live/Realtime ses
 * sistemine geçmek yalnızca yeni bir uygulayıcı yazmayı gerektirir.
 */
interface SpeechRecognizerService {
    /** Bir dinleme turu başlatır; Final veya Error olayından sonra akış biter. Ana iş parçacığından toplanmalıdır. */
    fun listen(): Flow<SpeechEvent>
}

/** Metni sesli okur. */
interface TextToSpeechService {
    fun speak(text: String)
    fun stop()
    fun shutdown()
}

/** Android SpeechRecognizer ile Türkçe konuşma tanıma. RECORD_AUDIO izni çağıran tarafından alınmış olmalıdır. */
class AndroidSpeechRecognizerService(private val context: Context) : SpeechRecognizerService {

    override fun listen(): Flow<SpeechEvent> = callbackFlow {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            trySend(SpeechEvent.Error("Bu cihazda konuşma tanıma kullanılamıyor."))
            close()
            awaitClose { }
            return@callbackFlow
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                trySend(SpeechEvent.Listening)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                firstResult(partialResults)?.let { trySend(SpeechEvent.Partial(it)) }
            }

            override fun onResults(results: Bundle?) {
                val text = firstResult(results)
                trySend(
                    if (text.isNullOrBlank()) SpeechEvent.Error("Sizi duyamadım.") else SpeechEvent.Final(text)
                )
                close()
            }

            override fun onError(error: Int) {
                trySend(SpeechEvent.Error(messageFor(error)))
                close()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
        awaitClose {
            recognizer.cancel()
            recognizer.destroy()
        }
    }

    private fun firstResult(bundle: Bundle?): String? =
        bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun messageFor(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni verilmemiş."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Sizi duyamadım."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Konuşma tanıma için ağ bağlantısı gerekiyor."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Konuşma tanıma meşgul."
        else -> "Konuşma tanınamadı."
    }
}

/** Android TextToSpeech ile Türkçe okuma. Motor hazır olmadan gelen metin hazır olunca okunur. */
class AndroidTextToSpeechService(context: Context) : TextToSpeechService {

    private var ready = false
    private var queued: String? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                val result = engine.setLanguage(Locale.forLanguageTag("tr-TR"))
                ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                if (ready) queued?.let { engine.speak(it, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
                queued = null
            }
        }
    }

    override fun speak(text: String) {
        val engine = tts ?: return
        if (ready) engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") else queued = text
    }

    override fun stop() {
        tts?.stop()
    }

    override fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
