package com.jarvis.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [DeviceEntity::class, CommandHistoryEntity::class, SettingsEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun commandHistoryDao(): CommandHistoryDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        fun create(context: Context): JarvisDatabase =
            Room.databaseBuilder(context.applicationContext, JarvisDatabase::class.java, "jarvis.db")
                .build()
    }
}
