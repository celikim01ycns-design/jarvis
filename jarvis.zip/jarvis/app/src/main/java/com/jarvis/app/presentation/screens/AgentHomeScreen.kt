package com.jarvis.app.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.accessibility.JarvisAccessibilityService
import com.jarvis.app.data.SettingsRepository
import com.jarvis.app.network.AgentClient
import com.jarvis.app.network.AgentStatus
import com.jarvis.app.presentation.AgentViewModel
import com.jarvis.app.presentation.theme.JarvisColors

/** Agent ana ekranı: eşleşme, bağlantı durumu (her zaman görünür), izinli komutlar, son komutlar. */
@Composable
fun AgentHomeScreen(vm: AgentViewModel, onSettings: () -> Unit) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val deviceName by vm.deviceName.collectAsStateWithLifecycle()
    val formError by vm.formError.collectAsStateWithLifecycle()

    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf(SettingsRepository.DEFAULT_PORT.toString()) }
    var code by remember { mutableStateOf("") }
    var accessibilityOn by remember { mutableStateOf(JarvisAccessibilityService.isEnabled(context)) }

    LifecycleResumeEffect(Unit) {
        accessibilityOn = JarvisAccessibilityService.isEnabled(context)
        onPauseOrDispose { }
    }

    val connected = state.status == AgentStatus.CONNECTED
    val busy = state.status == AgentStatus.CONNECTING || state.status == AgentStatus.RECONNECTING

    Column(
        Modifier.fillMaxSize().background(JarvisColors.Background).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("JARVIS Agent", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = JarvisColors.Cyan)
                Text(deviceName, color = JarvisColors.Muted, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Ayarlar", tint = JarvisColors.Cyan) }
        }

        // Bağlantı durumu — kullanıcı her zaman görür
        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(connected)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        when (state.status) {
                            AgentStatus.CONNECTED -> "Bağlı: ${state.serverName ?: "Server"}"
                            AgentStatus.CONNECTING -> state.message
                            AgentStatus.RECONNECTING -> state.message
                            AgentStatus.IDLE -> state.message
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (connected) {
                        Text("Server bu cihaza aşağıdaki komutları gönderebilir.", style = MaterialTheme.typography.bodySmall, color = JarvisColors.Muted)
                    }
                }
            }
        }

        if (!state.paired) {
            Text("Bu cihazı bir JARVIS Server'a bağla", style = MaterialTheme.typography.titleMedium)
            Text(
                "Server telefonunda Cihazlar > Yeni cihaz ekle ekranındaki adresi ve kodu girin.",
                color = JarvisColors.Muted, style = MaterialTheme.typography.bodyMedium
            )
            OutlinedTextField(host, { host = it }, label = { Text("Server adresi (örn. 192.168.1.20)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(code, { code = it.uppercase() }, label = { Text("Eşleştirme kodu (JARVIS-XXXX-XXXX)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth())
            formError?.let { Text(it, color = JarvisColors.Error) }
            Button(onClick = { vm.pair(host, port, code) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Eşleştir ve bağlan") }
        } else {
            if (connected || busy) {
                OutlinedButton(onClick = vm::disconnect, modifier = Modifier.fillMaxWidth()) { Text("Bağlantıyı kes") }
            } else {
                Button(onClick = vm::connect, modifier = Modifier.fillMaxWidth()) { Text("Server'a bağlan") }
            }
            OutlinedButton(
                onClick = vm::forgetServer,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisColors.Error),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Eşleşmeyi kaldır") }
        }

        Card {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Çalıştırılabilecek komutlar", style = MaterialTheme.typography.titleSmall)
                AgentClient.ALLOWED_COMMANDS.forEach { Text("• $it", color = JarvisColors.Muted) }
                Text(
                    if (accessibilityOn) "Erişilebilirlik hizmeti açık: uygulamalar arka plandayken de açılabilir."
                    else "Erişilebilirlik hizmeti kapalı: JARVIS arka plandayken uygulama açamayabilir. Ayarlar'dan siz açabilirsiniz.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (accessibilityOn) JarvisColors.Online else JarvisColors.Muted,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        if (recent.isNotEmpty()) {
            Card {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Son çalıştırılan komutlar", style = MaterialTheme.typography.titleSmall)
                    recent.forEach { Text(it, color = JarvisColors.Muted, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(JarvisColors.Surface).padding(16.dp)
    ) { content() }
}
