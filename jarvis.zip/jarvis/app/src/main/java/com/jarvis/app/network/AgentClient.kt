package com.jarvis.app.network

import com.jarvis.app.commands.CommandExecutor
import com.jarvis.app.data.PairedServer
import com.jarvis.app.data.SettingsRepository
import com.jarvis.app.domain.JarvisAction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AgentStatus { IDLE, CONNECTING, CONNECTED, RECONNECTING }

data class AgentUiState(
    val status: AgentStatus = AgentStatus.IDLE,
    val message: String = "Bağlı değil",
    val serverName: String? = null,
    val paired: Boolean = false
)

/**
 * Agent tarafı WebSocket istemcisi (OkHttp). Kullanıcı görünür ve kontrol edilebilir:
 *  - Durum her zaman [state] ile arayüze yansır, [disconnect] ile istenildiği an kesilir.
 *  - Gelen her komut doğrulanır (hedef cihaz, kaynak Server) ve yalnızca izinli eylemler çalışır
 *    ([ALLOWED_COMMANDS]); çalıştırılan komutlar [recent] listesinde görünür.
 */
class AgentClient(
    private val http: OkHttpClient,
    private val settings: SettingsRepository,
    private val executor: CommandExecutor,
    private val scope: CoroutineScope
) {
    private sealed class Outcome {
        object Paired : Outcome()
        data class Ended(val wasConnected: Boolean) : Outcome()
        data class Fatal(val message: String) : Outcome()
    }

    private val _state = MutableStateFlow(AgentUiState())
    val state: StateFlow<AgentUiState> = _state

    private val _recent = MutableStateFlow<List<String>>(emptyList())

    /** "14:32 · Spotify aç → başarılı" biçiminde son çalıştırılan komutlar. */
    val recent: StateFlow<List<String>> = _recent

    private var job: Job? = null

    @Volatile
    private var socket: WebSocket? = null

    /** Açılışta eşleşmiş Server bilgisi var mı diye bakar ve durumu günceller. */
    suspend fun refreshPairedState() {
        val server = settings.getPairedServer()
        _state.update { it.copy(paired = server != null, serverName = server?.serverName) }
    }

    /** Server'ın gösterdiği tek kullanımlık kodla ilk eşleşmeyi yapar, ardından bağlı kalır. */
    fun pair(host: String, port: Int, code: String) {
        launchJob {
            val deviceId = settings.getDeviceId()
            val deviceName = settings.getDeviceName()
            val first = PairRequest(code.trim(), deviceId, deviceName)
            when (val outcome = session(host.trim(), port, first, "Eşleştiriliyor...")) {
                Outcome.Paired -> reconnectLoop()
                is Outcome.Fatal -> _state.value = AgentUiState(AgentStatus.IDLE, outcome.message, paired = false)
                is Outcome.Ended -> _state.value =
                    AgentUiState(AgentStatus.IDLE, "Eşleştirme tamamlanamadı. Server'a ulaşılamadı.", paired = false)
            }
        }
    }

    /** Daha önce eşleşilen Server'a token ile bağlanır; koparsa kullanıcı kesmedikçe yeniden dener. */
    fun connect() {
        launchJob { reconnectLoop() }
    }

    /** Bağlantıyı keser ve otomatik yeniden bağlanmayı durdurur. Eşleşme saklı kalır. */
    fun disconnect() {
        job?.cancel()
        job = null
        socket?.close(NORMAL_CLOSURE, "Kullanıcı bağlantıyı kesti")
        socket = null
        scope.launch {
            val server = settings.getPairedServer()
            _state.value = AgentUiState(
                AgentStatus.IDLE, "Bağlantı kesildi", server?.serverName, paired = server != null
            )
        }
    }

    /** Eşleşmeyi tamamen siler; yeniden bağlanmak için yeni kod gerekir. */
    fun forgetServer() {
        job?.cancel()
        job = null
        socket?.close(NORMAL_CLOSURE, "Eşleşme kaldırıldı")
        socket = null
        scope.launch {
            settings.clearPairedServer()
            _state.value = AgentUiState()
        }
    }

    private fun launchJob(block: suspend () -> Unit) {
        job?.cancel()
        socket?.cancel()
        job = scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = AgentUiState(AgentStatus.IDLE, "Beklenmeyen bir hata oluştu.")
            }
        }
    }

    private suspend fun reconnectLoop() {
        var backoff = MIN_BACKOFF_MS
        while (currentCoroutineContext().isActive) {
            val server = settings.getPairedServer()
            if (server == null) {
                _state.value = AgentUiState(AgentStatus.IDLE, "Eşleşmiş Server yok", paired = false)
                return
            }
            val deviceId = settings.getDeviceId()
            val label = if (backoff == MIN_BACKOFF_MS) "Bağlanılıyor..." else "Yeniden bağlanılıyor..."
            when (val outcome = session(server.host, server.port, Auth(deviceId, server.sessionToken), label)) {
                is Outcome.Fatal -> {
                    val stillPaired = settings.getPairedServer() != null
                    _state.value = AgentUiState(
                        AgentStatus.IDLE,
                        outcome.message,
                        if (stillPaired) server.serverName else null,
                        paired = stillPaired
                    )
                    return
                }
                is Outcome.Ended -> {
                    if (outcome.wasConnected) backoff = MIN_BACKOFF_MS
                    _state.value = AgentUiState(
                        AgentStatus.RECONNECTING,
                        "Bağlantı koptu, yeniden deneniyor...",
                        server.serverName,
                        paired = true
                    )
                    delay(backoff)
                    backoff = minOf(backoff * 2, MAX_BACKOFF_MS)
                }
                Outcome.Paired -> Unit
            }
        }
    }

    /** Tek bir WebSocket oturumu: bağlanır, kimlik doğrular, kapanana kadar komutları işler. */
    private suspend fun session(host: String, port: Int, first: ProtocolMessage, label: String): Outcome {
        _state.update { it.copy(status = AgentStatus.CONNECTING, message = label) }
        val finished = CompletableDeferred<Outcome>()
        var connected = false

        val request = try {
            Request.Builder().url("ws://$host:$port${WebSocketManager.PATH}").build()
        } catch (e: IllegalArgumentException) {
            return Outcome.Fatal("Server adresi geçersiz.")
        }

        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(CommandProtocol.encode(first))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                when (val message = CommandProtocol.decode(text)) {
                    is PairAccepted -> scope.launch {
                        settings.savePairedServer(
                            PairedServer(message.serverId, message.serverName, host, port, message.sessionToken)
                        )
                        connected = true
                        _state.value = AgentUiState(
                            AgentStatus.CONNECTED, "Bağlı", message.serverName, paired = true
                        )
                        finished.complete(Outcome.Paired)
                        // Eşleşme sonrası bu oturum kapatılır; reconnectLoop token ile yeniden bağlanır.
                        webSocket.close(NORMAL_CLOSURE, "pairing complete")
                    }
                    is PairRejected -> {
                        finished.complete(Outcome.Fatal(message.reason))
                        webSocket.close(NORMAL_CLOSURE, "rejected")
                    }
                    is AuthOk -> {
                        connected = true
                        scope.launch {
                            val server = settings.getPairedServer()
                            _state.value = AgentUiState(
                                AgentStatus.CONNECTED, "Bağlı", server?.serverName, paired = true
                            )
                        }
                    }
                    is AuthFailed -> {
                        scope.launch {
                            settings.clearPairedServer()
                            finished.complete(
                                Outcome.Fatal("Eşleşme geçersiz. Server'dan yeni bir kod isteyin.")
                            )
                        }
                        webSocket.close(NORMAL_CLOSURE, "auth failed")
                    }
                    is Command -> scope.launch { handleCommand(webSocket, message) }
                    is Ping -> webSocket.send(CommandProtocol.encode(Pong(message.timestamp)))
                    is Disconnect -> {
                        finished.complete(Outcome.Fatal(message.reason))
                        webSocket.close(NORMAL_CLOSURE, "server requested disconnect")
                    }
                    else -> Unit
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(NORMAL_CLOSURE, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                finished.complete(Outcome.Ended(connected))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                finished.complete(Outcome.Ended(connected))
            }
        }

        val ws = http.newWebSocket(request, listener)
        socket = ws
        try {
            return finished.await()
        } finally {
            if (socket === ws) socket = null
            ws.cancel()
        }
    }

    private suspend fun handleCommand(ws: WebSocket, command: Command) {
        val server = settings.getPairedServer()
        val myId = settings.getDeviceId()

        val reject = when {
            server == null || command.sourceDevice != server.serverId -> "Komut eşleşmiş Server'dan gelmedi."
            command.targetDevice != myId -> "Komut bu cihaz için değil."
            else -> null
        }
        val result = if (reject != null) {
            CommandResultMessage(command.commandId, false, reject)
        } else {
            val action: JarvisAction = command.action.toLocalAction()
            val outcome = try {
                executor.execute(action)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                com.jarvis.app.domain.CommandResult.fail("Komut çalıştırılırken bir hata oluştu.")
            }
            CommandResultMessage(command.commandId, outcome.success, outcome.message)
        }
        remember(describe(command.action), result.success)
        ws.send(CommandProtocol.encode(result))
    }

    private fun describe(payload: ActionPayload): String = when (payload) {
        is OpenAppPayload -> "${payload.app} aç"
        DeviceStatusPayload -> "Cihaz durumu"
    }

    private fun remember(text: String, success: Boolean) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val line = "$time · $text → ${if (success) "başarılı" else "başarısız"}"
        _recent.update { (listOf(line) + it).take(MAX_RECENT) }
    }

    companion object {
        /** Agent'ın kabul ettiği komutlar; arayüzde kullanıcıya gösterilir. */
        val ALLOWED_COMMANDS = listOf("Uygulama aç (open_app)", "Cihaz durumunu bildir (device_status)")

        private const val NORMAL_CLOSURE = 1000
        private const val MIN_BACKOFF_MS = 1_000L
        private const val MAX_BACKOFF_MS = 15_000L
        private const val MAX_RECENT = 20
    }
}
