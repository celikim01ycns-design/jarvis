package com.jarvis.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JarvisColors {
    val Background = Color(0xFF0A0F1A)
    val Surface = Color(0xFF121B2B)
    val SurfaceHigh = Color(0xFF1A2640)
    val Cyan = Color(0xFF00E5FF)
    val Online = Color(0xFF3DDC84)
    val Offline = Color(0xFF6B7A90)
    val Error = Color(0xFFFF5252)
    val Text = Color(0xFFE6F1FF)
    val Muted = Color(0xFF8DA2BF)
}

private val scheme = darkColorScheme(
    primary = JarvisColors.Cyan,
    onPrimary = Color(0xFF00232B),
    secondary = JarvisColors.Online,
    background = JarvisColors.Background,
    onBackground = JarvisColors.Text,
    surface = JarvisColors.Surface,
    onSurface = JarvisColors.Text,
    surfaceVariant = JarvisColors.SurfaceHigh,
    onSurfaceVariant = JarvisColors.Muted,
    error = JarvisColors.Error,
    outline = JarvisColors.Offline
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
