package com.jarvis.app.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.app.presentation.JarvisViewModel
import com.jarvis.app.presentation.theme.JarvisColors
import kotlinx.coroutines.launch

@Composable
fun DeviceDetailScreen(vm: JarvisViewModel, deviceId: String, onBack: () -> Unit) {
    val devices by vm.devices.collectAsStateWithLifecycle()
    val device = devices.firstOrNull { it.id == deviceId }
    var name by remember(device?.id) { mutableStateOf(device?.name.orEmpty()) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Cihaz kaldırılınca ekrandan çık.
    LaunchedEffect(device == null) { if (device == null) onBack() }

    Scaffold(containerColor = JarvisColors.Background, topBar = { JarvisTopBar(device?.name ?: "Cihaz", onBack) }) { padding ->
        if (device == null) return@Scaffold
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(device.online)
                Spacer(Modifier.width(10.dp))
                Text(if (device.online) "Çevrimiçi" else "Çevrimdışı", style = MaterialTheme.typography.titleMedium)
            }
            Text("Son görülme: ${formatLastSeen(device.lastSeen)}", color = JarvisColors.Muted)

            OutlinedTextField(
                value = name,
                onValueChange = { name = it; message = null },
                label = { Text("Cihaz adı") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    scope.launch {
                        message = if (vm.renameDevice(device.id, name)) "Ad güncellendi."
                        else "Bu ad boş olamaz veya başka bir cihazda kullanılıyor."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Adı kaydet") }
            message?.let { Text(it, color = JarvisColors.Muted) }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { vm.disconnectDevice(device.id) },
                enabled = device.online,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Bağlantıyı kes") }
            Button(
                onClick = { confirmRemove = true },
                colors = ButtonDefaults.buttonColors(containerColor = JarvisColors.Error),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Cihazı kaldır") }
        }
    }

    if (confirmRemove && device != null) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Cihaz kaldırılsın mı?") },
            text = { Text("${device.name} Server'dan silinir ve oturumu geçersiz olur. Tekrar bağlanmak için yeniden eşleştirmek gerekir.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = false
                    vm.removeDevice(device.id)
                }) { Text("Kaldır") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Vazgeç") } }
        )
    }
}
